<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // conexão centralizada

$empresa_id = $_SESSION['empresa_id'] ?? 0;
$data = $_POST['data_suspensa'] ?? null;

if ($empresa_id && $data) {

    $sql = "INSERT INTO dias_suspensos (empresa_id, data) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("is", $empresa_id, $data);
        $stmt->execute();
        $stmt->close(); // ✅ fechar statement
    } else {
        die("Erro no prepare: " . $conn->error);
    }
}

header("Location: informacoes.php");
exit;
?>
