<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST["email"];
    $senha = $_POST["senha"];

    // 🔥 PREPARED STATEMENT (mais seguro)
    $stmt = $conn->prepare("SELECT * FROM cadastro_empresa WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {

        $usuario = $result->fetch_assoc();

        if (password_verify($senha, $usuario["senha"])) {

            $_SESSION["empresa_id"] = $usuario["id_empresa"];
            $_SESSION["empresa_nome"] = $usuario["nome_empresa"];

            header("Location: transicaoAdmin.html");
            exit;

        } else {
            echo "senha_incorreta";
        }

    } else {
        echo "email_nao_encontrado";
    }

    // Fechar statement (opcional)
    $stmt->close();
}
?>
