<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST["email"];
    $senha = $_POST["senha"];

    $stmt = $conn->prepare("SELECT id, nome, senha FROM cadastro_usuario WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {

        $usuario = $resultado->fetch_assoc();

        if (password_verify($senha, $usuario["senha"])) {

            // ✅ SESSÃO CORRIGIDA
            $_SESSION["id"] = $usuario["id"];
            $_SESSION["nome"] = $usuario["nome"];
            $_SESSION["email"] = $email;

            echo "sucesso";

        } else {
            echo "senha_incorreta";
        }

    } else {
        echo "nao_encontrado";
    }

    // Fechar statement (opcional)
    $stmt->close();
}

// Não fechamos $conn, ele vem de conexao.php e pode ser usado em outros scripts
?>
