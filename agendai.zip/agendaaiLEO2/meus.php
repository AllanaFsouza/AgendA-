<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login_cliente.html");
    exit;
}

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

$id_usuario = $_SESSION['id'];

// BUSCAR TODOS OS AGENDAMENTOS
$sql = "SELECT * FROM agendamentos_cliente WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$result = $stmt->get_result();
$agendamentos = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// AGENDAMENTOS ATIVOS
$sqlAtivos = "SELECT * FROM agendamentos_cliente WHERE id_usuario = ? AND status = 'ativo'";
$stmt = $conn->prepare($sqlAtivos);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$ativos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// AGENDAMENTOS CANCELADOS
$sqlCancelados = "SELECT * FROM agendamentos_cliente WHERE id_usuario = ? AND status = 'cancelado'";
$stmt = $conn->prepare($sqlCancelados);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$cancelados = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// AGENDAMENTOS CONCLUÍDOS
$sqlConcluidos = "SELECT * FROM agendamentos_cliente WHERE id_usuario = ? AND status = 'concluido'";
$stmt = $conn->prepare($sqlConcluidos);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();
$concluidos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// ✅ $conn não é fechado pois vem do conexao.php e pode ser usado em outros scripts
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Empresa | Meus Agendamentos</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>
:root { --cor-tema: #6C63FF; }
* { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
body { background: #f9fafb; color: #2d3748; line-height: 1.5; min-height: 100vh; overflow-x: hidden; width: 100%; }
header { background: var(--cor-tema); color: white; padding: 15px 20px; position: sticky; top: 0; z-index: 100; }
.header-content { display: flex; justify-content: space-between; align-items: center; max-width: 100%; margin: 0; }
.logo-header { font-size: 20px; font-weight: 700; display: flex; align-items: center; gap: 10px; }
nav { display: flex; gap: 10px; }
.nav-button { background: #fff; color: var(--cor-tema); border: none; border-radius: 12px; padding: 8px 18px; cursor: pointer; font-weight: 700; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; font-size: 14px; transition: .3s; }
.nav-button:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.15); }
.nav-button.active { background: var(--cor-tema); color: #fff; border: 1px solid rgba(255,255,255,0.3); }
.header-user { display: flex; flex-direction: column; align-items: center; gap: 4px; }
.perfil-icon { background: white; color: var(--cor-tema); border: none; width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 16px; transition: .3s; }
.logout-header { font-size: 12px; text-decoration: none; color: white; opacity: .9; font-weight: 600; cursor: pointer; }
.hero { background: var(--cor-tema); color: white; padding: 60px 20px 100px 20px; text-align: center; }
.hero p { font-weight: 500; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 1px; margin-bottom: 8px; opacity: 0.9; }
.hero h1 { font-size: 2.2rem; font-weight: 800; }
.main { max-width: 1000px; margin: -60px auto 40px; padding: 0 20px; }
.appointments-container { display: flex; flex-direction: column; gap: 15px; }
.appointment-card { background: white; padding: 24px; border-radius: 24px; box-shadow: 0 10px 25px rgba(0,0,0,0.06); display: flex; justify-content: space-between; align-items: center; transition: .3s; animation: slideUp 0.4s ease-out; }
.appointment-card:hover { transform: translateY(-3px); }
.app-info { display: flex; flex-direction: column; gap: 6px; }
.app-info strong { font-size: 1.1rem; color: #1a202c; font-weight: 700; }
.app-info span { font-size: 0.9rem; color: #64748b; display: flex; align-items: center; gap: 10px; font-weight: 500; }
.app-info i { color: var(--cor-tema); width: 18px; font-size: 1.1rem; }
.btn-cancelar-job { background: #fff0f0; color: #e74c3c; border: 2px solid #ffeded; padding: 12px 24px; border-radius: 16px; font-weight: 700; cursor: pointer; transition: .3s; font-size: 0.9rem; }
.btn-cancelar-job:hover { background: #e74c3c; color: white; box-shadow: 0 4px 12px rgba(231, 76, 60, 0.2); }
.modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.45); backdrop-filter: blur(4px); z-index: 1000; align-items: center; justify-content: center; }
.modal-content { background: white; width: 420px; border-radius: 20px; padding: 35px; position: relative; border: 2px solid var(--cor-tema); box-shadow: 0 25px 60px rgba(0,0,0,0.25); animation: modalEntrada .35s ease; }
.modal-logout { text-align: center; }
.close-btn { position: absolute; top: 15px; right: 18px; font-size: 20px; cursor: pointer; color: #999; }
.perfil-form { display: flex; flex-direction: column; gap: 12px; margin-top: 15px; text-align: left; }
.perfil-form label { font-size: 0.9rem; font-weight: 600; color: #4a5568; }
.perfil-form input { padding: 12px; border-radius: 10px; border: 1px solid #e2e8f0; outline: none; transition: .2s; }
.perfil-form input:focus { border-color: var(--cor-tema); }
.btn-primario { background: var(--cor-tema); color: white; border: none; padding: 14px; border-radius: 14px; font-weight: 700; cursor: pointer; margin-top: 10px; transition: .3s; }
.btn-primario:hover { opacity: 0.9; transform: translateY(-2px); }
.btn-secundario { background: #f1f5f9; border: none; padding: 12px; border-radius: 12px; cursor: pointer; font-weight: 600; color: #64748b; }
.logout-botoes { display: flex; gap: 10px; margin-top: 25px; }
.btn-confirmar { flex: 1; background: #e74c3c; color: white; border: none; padding: 12px; border-radius: 12px; cursor: pointer; font-weight: 700; }
.btn-cancelar { flex: 1; background: #f1f5f9; border: none; padding: 12px; border-radius: 12px; cursor: pointer; font-weight: 600; color: #64748b; }
.modal-saindo { animation: modalSaida .3s ease forwards; }
@keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
@keyframes modalEntrada { from { opacity: 0; transform: translateY(20px) scale(.95); } to { opacity: 1; transform: translateY(0) scale(1); } }
@keyframes modalSaida { from { opacity: 1; transform: translateY(0) scale(1); } to { opacity: 0; transform: translateY(20px) scale(.9); } }
@media (max-width: 600px) { .appointment-card { flex-direction: column; align-items: flex-start; gap: 20px; } .btn-cancelar-job { width: 100%; } }

.perfil-dado{
    padding:12px;
    border-radius:10px;
    background:#f1f5f9;
    border:1px solid #e2e8f0;
    font-weight:500;
    color:#2d3748;
}
.nav-button {
    background: var(--cor-tema);
    color: #fff;
}

.nav-button.active {
    background: #fff;
    color: var(--cor-tema);
}

</style>
</head>

<body>


<!-- CABEÇALHO -->
<header>
<div class="header-content">
<div class="logo-header"><i class="fa-solid fa-scissors"></i>AgendaAí</div>
<nav>
<a href="dashboardcliente.php" class="nav-button active">Início</a>
<a href="agendar.php" class="nav-button active">Agendar</a>
<a href="#" class="nav-button active">Meus</a>

</nav>
<div class="header-user">
<button class="perfil-icon" onclick="abrirPerfilModal()"><i class="fa-solid fa-user"></i></button>
<a class="logout-header" onclick="abrirModalLogout()">Sair</a>
</div></div>
</header>

<!-- CONTEÚDO DA PÁGINA -->
<section class="hero">
<p>Histórico e Próximos</p>
<h1>Meus Agendamentos 📅</h1>
</section>
<div class="main">
<div class="appointments-container">
<div style="display:flex; gap:10px; margin-bottom:20px;">
    <button id="btn-ativos" class="nav-button active" onclick="trocarAba('ativos')">Ativos</button>
    <button id="btn-cancelados" class="nav-button" onclick="trocarAba('cancelados')">Cancelados</button>
<button id="btn-concluidos" class="nav-button" onclick="trocarAba('concluidos')">
    Concluídos
</button>

</div>



</div>
<div id="aba-ativos">
<?php if (count($ativos) > 0): ?>
    <?php foreach ($ativos as $agendamento): ?>
        <div class="appointment-card" data-id="<?php echo $agendamento['id']; ?>">
            <div class="app-info">
                <strong><?php echo $agendamento['servicos']; ?></strong>

                <span><i class="fa-regular fa-calendar"></i>
                <?php echo date('d/m/Y', strtotime($agendamento['data_agendamento'])); ?>
                </span>

                <span><i class="fa-regular fa-clock"></i>
                <?php echo substr($agendamento['horario'], 0, 5); ?>
                </span>
            </div>

            <button class="btn-cancelar-job" onclick="abrirModalAcao(this)">
                Cancelar
            </button>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>Nenhum agendamento ativo</p>
<?php endif; ?>
</div>
<div id="aba-cancelados" style="display:none;">
<?php if (count($cancelados) > 0): ?>
    <?php foreach ($cancelados as $agendamento): ?>
        <div class="appointment-card" style="opacity:0.6;">
            <div class="app-info">
                <strong><?php echo $agendamento['servicos']; ?> (Cancelado)</strong>

                <span><i class="fa-regular fa-calendar"></i>
                <?php echo date('d/m/Y', strtotime($agendamento['data_agendamento'])); ?>
                </span>

                <span><i class="fa-regular fa-clock"></i>
                <?php echo substr($agendamento['horario'], 0, 5); ?>
                </span>
            </div>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>Nenhum cancelado</p>
<?php endif; ?>
</div>
<div id="aba-concluidos" style="display:none;">
<?php if (count($concluidos) > 0): ?>
    <?php foreach ($concluidos as $agendamento): ?>
        <div class="appointment-card" style="opacity:0.8;">
            <div class="app-info">
                <strong><?php echo $agendamento['servicos']; ?> (Concluído)</strong>

                <span><i class="fa-regular fa-calendar"></i>
                <?php echo date('d/m/Y', strtotime($agendamento['data_agendamento'])); ?>
                </span>

                <span><i class="fa-regular fa-clock"></i>
                <?php echo substr($agendamento['horario'], 0, 5); ?>
                </span>
            </div>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>Nenhum agendamento concluído</p>
<?php endif; ?>
</div>


<!-- MODAL PERFIL -->
<div class="modal-overlay" id="modalPerfil">
<div class="modal-content">
<span class="close-btn" onclick="fecharPerfilModal()">&times;</span>
<h2 style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-circle-user" style="color:var(--cor-tema)"></i> Perfil</h2>
<form class="perfil-form">
<label>Nome</label>
<div class="perfil-dado"><?php echo $_SESSION['nome'] ?? 'Não definido'; ?></div>

<label>Email</label>
<div class="perfil-dado"><?php echo $_SESSION['email'] ?? 'Não definido'; ?></div>
</form>

</div></div>

<!-- MODAL LOGOUT -->
<div class="modal-overlay" id="modalLogout">
<div class="modal-content modal-logout">
<h2><i class="fa-solid fa-right-from-bracket"></i> Sair</h2>
<p style="margin-top:10px;color:#666;">Tem certeza que deseja encerrar sua sessão?</p>
<div class="logout-botoes">
<button class="btn-cancelar" onclick="fecharModalLogout()">Cancelar</button>
<button class="btn-confirmar" onclick="confirmarLogout()">Sim, sair</button>
</div></div></div>

<!-- MODAL CONFIRMAR CANCELAMENTO DO AGENDAMENTO -->
<div class="modal-overlay" id="modalConfirmarCancelamento">
<div class="modal-content modal-logout">
<h2><i class="fa-solid fa-triangle-exclamation"></i> Cancelar</h2>
<p style="margin-top:10px;color:#666;">Deseja cancelar este agendamento?</p>
<div class="logout-botoes">
<button class="btn-cancelar" onclick="fecharComAnimacao('modalConfirmarCancelamento')">Voltar</button>
<button class="btn-confirmar" onclick="executarCancelamento()">Sim, cancelar</button>

</div>
</div>
</div>

<script>
// ================= MODAIS =================
function abrirPerfilModal() {
    document.getElementById("modalPerfil").style.display = "flex";
}

function fecharPerfilModal() {
    fecharComAnimacao("modalPerfil");
}

function abrirModalLogout(){
    document.getElementById("modalLogout").style.display="flex";
}

function fecharModalLogout(){
    fecharComAnimacao("modalLogout");
}

function confirmarLogout(){
    window.location.href = "login_cliente.html"; 
}

function fecharComAnimacao(id){
    const overlay = document.getElementById(id);
    const modal = overlay.querySelector(".modal-content");

    modal.classList.add("modal-saindo");

    setTimeout(()=>{
        overlay.style.display="none";
        modal.classList.remove("modal-saindo");
    },300);
}

// ================= LISTA =================
function verificarListaVazia() {
    const container = document.querySelector('.appointments-container');

    if (!container) return;

    if (container.children.length === 0) {
        container.innerHTML = `
            <div style="text-align:center; padding: 40px; color: #64748b;">
                <i class="fa-regular fa-calendar-minus" style="font-size: 3rem; margin-bottom: 15px; display: block; opacity: 0.5;"></i>
                <p>Você não possui agendamentos ativos.</p>
            </div>`;
    }
}

// ================= CANCELAMENTO =================
let itemParaRemover = null;

function abrirModalAcao(botao) {
    itemParaRemover = botao.closest('.appointment-card');
    document.getElementById("modalConfirmarCancelamento").style.display = "flex";
}

function executarCancelamento() {
    if (!itemParaRemover) return;

    const idParaRemover = itemParaRemover.getAttribute('data-id');

    fetch("cancelar_agendamento.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "id=" + idParaRemover
    })
    .then(res => res.text())
    .then(res => {
        console.log("Resposta:", res);

        if(res.trim() === "ok"){
            itemParaRemover.remove();
            verificarListaVazia();
        } else {
            alert("Erro ao cancelar");
        }
    })
    .catch(err => {
        console.error("Erro:", err);
    });

    fecharComAnimacao('modalConfirmarCancelamento');
}

// ================= ABAS =================
function trocarAba(aba){
    const abas = ["ativos", "cancelados", "concluidos"];

    abas.forEach(a => {
        document.getElementById("aba-" + a).style.display = "none";
        document.getElementById("btn-" + a).classList.remove("active");
    });

    document.getElementById("aba-" + aba).style.display = "block";
    document.getElementById("btn-" + aba).classList.add("active");
}

// ================= INIT =================
window.onload = () => {
    let cor = localStorage.getItem("corTemaSite");
    if(cor) {
        document.documentElement.style.setProperty('--cor-tema', cor);
    }
};
</script>

<script src="transicao.js"></script>

</body>
</html> 