<?php
session_start();
$nome_usuario = $_SESSION['empresa_nome'] ?? 'Admin';
$email_usuario = $_SESSION['empresa_email'] ?? 'admin@gmail.com';

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

$id_empresa = $_SESSION['empresa_id'] ?? 15; // pegar da sessão ou usar 15 como fallback

$sql = "SELECT * FROM cadastro_empresa WHERE id_empresa = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_empresa);
$stmt->execute();

$result = $stmt->get_result();
$empresa = $result->fetch_assoc();

// Fechar statement (opcional)
$stmt->close();
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sua Empresa | Dados Cadastrais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background: #e5e5e5;
            overflow: hidden;
        }

        /* --- SIDEBAR PADRONIZADA --- */
        .sidebar {
            width: 280px;
            background: #1b1f4b;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
        }

        .logo {
            padding: 25px 20px;
            font-weight: 800;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .menu {
            flex: 1;
            padding: 10px 0;
        }

        .menu-title {
            padding: 15px 20px 5px 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.5;
            font-weight: 600;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
        }

        .menu a i {
            width: 20px;
            text-align: center;
            font-size: 16px;
        }

        .menu a:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .menu a.active {
            background: #4e63ff;
            font-weight: 600;
        }

        .sidebar-footer {
            padding: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .user-info-box {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info-box i {
            background: white;
            color: #1b1f4b;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .user-details strong { font-size: 13px; display: block; }
        .user-details span { font-size: 11px; opacity: 0.7; }

        .logout-btn {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            opacity: 0.8;
            transition: 0.2s;
            cursor: pointer;
        }

        /* --- CONTEÚDO --- */
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .page-header {
            background: white;
            padding: 20px 30px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-text h1 { font-size: 20px; color: #333; }
        .header-text p { font-size: 12px; color: #777; }

        .page-body { padding: 30px; }

        /* Container de Dados */
        .data-container {
            background: #f9f9f9;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
        }

        .section-header { display: flex; align-items: center; gap: 12px; margin-bottom: 30px; }
        .section-header i { font-size: 22px; color: #4e63ff; }
        .section-header h2 { font-size: 18px; color: #1b1f4b; }
        .section-header p { font-size: 12px; color: #888; }

        /* Grid Formulário */
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; }
        .input-group { display: flex; flex-direction: column; gap: 8px; }
        .input-label { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #555; font-weight: 600; }
        .input-label i { color: #4e63ff; font-size: 14px; }
        
        .form-grid input {
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background: white;
            outline: none;
            transition: 0.3s;
        }

        .form-grid input:focus { border-color: #4e63ff; box-shadow: 0 0 0 3px rgba(78, 99, 255, 0.1); }

        .btn-save {
            padding: 12px 30px;
            border-radius: 10px;
            background: #4e63ff;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: 600;
            transition: 0.3s;
        }

        .btn-save:hover { background: #3a4df0; }
        .btn-save {
    /* ... seus estilos anteriores ... */
    transition: background 0.4s ease, transform 0.2s;
}

.btn-save:disabled {
    cursor: not-allowed;
    opacity: 0.8;
}
/* --- ESTILOS DO MODAL DE LOGOUT --- */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: none; /* Escondido por padrão */
    align-items: center;
    justify-content: center;
    z-index: 1000;
    backdrop-filter: blur(3px);
}

.modal-content {
    background: white;
    padding: 30px;
    border-radius: 20px;
    width: 350px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    animation: scaleUp 0.3s ease-out;
}

@keyframes scaleUp {
    from { transform: scale(0.8); opacity: 0; }
    to { transform: scale(1); opacity: 1; }
}

.modal-content i {
    font-size: 50px;
    color: #dc3545;
    margin-bottom: 15px;
}

.modal-content h3 {
    color: #1b1f4b;
    margin-bottom: 10px;
}

.modal-content p {
    color: #666;
    font-size: 14px;
    margin-bottom: 25px;
}

.modal-buttons {
    display: flex;
    gap: 15px;
    justify-content: center;
}

.btn-modal {
    padding: 10px 20px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    font-weight: 600;
    transition: 0.2s;
}

.btn-confirm { background: #dc3545; color: white; }
.btn-confirm:hover { background: #c82333; }
.btn-cancel { background: #eee; color: #555; }
.btn-cancel:hover { background: #ddd; }
    </style>
</head>

<body>
    <aside class="sidebar">
        <div>
               <div class="logo">
    <i class="fa-solid fa-scissors"></i> agendaAi
</div>

            <nav class="menu">
                <div class="menu-title">Editar site</div>
                <a href="dashboardadmin.php"><i class="fa-solid fa-chart-line"></i> Dashboard Inicial</a>
                <a href="previsualizacao_cliente.php"><i class="fa-regular fa-eye"></i> Pré-visualização</a>
                <a href="informacoes.php"><i class="fa-solid fa-circle-info"></i> Informações</a>
                <a href="#" class="active"><i class="fa-solid fa-id-card"></i> Dados da Empresa</a>

                <div class="menu-title">Gerenciar</div>
                <a href="servicos.php"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</a>
                <a href="equipe.php"><i class="fa-solid fa-users"></i> Equipe</a>
                <a href="agendamentos.php"><i class="fa-regular fa-calendar-check"></i> Agendamentos</a>
                <a href="clientes.php"><i class="fa-solid fa-user-group"></i> Clientes</a>
            </nav>
        </div>

        <div class="sidebar-footer">
            <div class="user-info-box">
                <i class="fa-solid fa-user"></i>
                <div class="user-details">
    <strong><?php echo htmlspecialchars($nome_usuario); ?></strong>
    <span><?php echo htmlspecialchars($email_usuario); ?></span>
</div>

            </div>
<a href="#" class="logout-btn" id="sidebarLogout">
    <i class="fa-solid fa-right-from-bracket"></i> Sair
</a>
        </div>
    </aside>

    <main class="content">
        <header class="page-header">
            <div class="header-text">
                <h1>Dados da Empresa</h1>
                <p>Gerencie as informações fiscais e de contato da sua conta</p>
            </div>
            <div class="notification-icon"><i class="fa-solid fa-bell"></i></div>
        </header>

        <div class="page-body">
            <div class="data-container">
                <div class="section-header">
                    <i class="fa-solid fa-file-invoice"></i>
                    <div>
                        <h2>Cadastro Institucional</h2>
                        <p>Essas informações são usadas para faturamento e identificação oficial</p>
                    </div>
                </div>

                <form action="salvar_dados_empresa.php" method="POST" class="form-grid">
                    
    <div class="input-group">
        <div class="input-label">
            <i class="fa-solid fa-briefcase"></i> Razão Social / Nome Fantasia
        </div>
        <input type="text" name="razao_social"
               value="<?php echo $empresa['nome_empresa']; ?>"
               placeholder="Ex: Barbearia do João LTDA" required>
    </div>

  <div class="input-group">
    <div class="input-label">
        <i class="fa-solid fa-envelope"></i> E-mail de Contato
    </div>
    <input type="email"
           value="<?php echo $empresa['email']; ?>"
           readonly>
</div>
    <div class="input-group">
        <div class="input-label">
            <i class="fa-solid fa-phone"></i> Telefone / WhatsApp
        </div>
        <input type="text" name="telefone"
               value="<?php echo $empresa['telefone']; ?>"
               placeholder="(11) 99999-9999">
    </div>

  <!-- SENHA -->
<div class="input-group">
    <div class="input-label">
        <i class="fa-solid fa-file-lines"></i> Senha
    </div>
    <input type="password"
           value="********"
           readonly>
</div>

    <div class="input-group">
        <div class="input-label">
            <i class="fa-solid fa-user-tie"></i> Nome do Responsável
        </div>
        <input type="text" name="responsavel"
               value="<?php echo $empresa['responsavel']; ?>"
               placeholder="Nome do proprietário">
    </div>

    <div style="grid-column: span 2; margin-top: 15px;">
        <button type="submit" class="btn-save">
            Atualizar Dados
        </button>
    </div>

</form>
            </div>
        </div>
    </main>

    <script>
    const form = document.querySelector('form');
    const btnSave = document.querySelector('.btn-save');

    form.addEventListener('submit', function (e) {
        e.preventDefault(); // Impede o recarregamento da página

        // Feedback visual de "Carregando"
        const originalText = btnSave.innerHTML;
        btnSave.disabled = true;
        btnSave.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Atualizando...';

        const formData = new FormData(this);

        fetch('salvar_dados_empresa.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (response.ok) {
                // SUCESSO: Muda a cor para verde e altera o texto
                btnSave.style.background = '#28a745'; // Verde
                btnSave.innerHTML = '<i class="fa-solid fa-check"></i> Atualizado com sucesso!';
                
                // Retorna ao estado original após 3 segundos
                setTimeout(() => {
                    btnSave.style.background = '#4e63ff'; // Azul original
                    btnSave.innerHTML = originalText;
                    btnSave.disabled = false;
                }, 3000);
            } else {
                throw new Error('Erro ao salvar');
            }
        })
        .catch(error => {
            // ERRO: Feedback visual de erro
            btnSave.style.background = '#dc3545'; // Vermelho
            btnSave.innerHTML = '<i class="fa-solid fa-xmark"></i> Erro ao atualizar';
            btnSave.disabled = false;
            
            setTimeout(() => {
                btnSave.style.background = '#4e63ff';
                btnSave.innerHTML = originalText;
            }, 3000);
        });
    });
    
    document.addEventListener('DOMContentLoaded', () => {
    const btnSair = document.getElementById('sidebarLogout');
    const modal = document.getElementById('modalLogout');
    const btnCancel = document.getElementById('logout-buton');
    const btnConfirm = document.getElementById('btnConfirmLogout');

    // Abre o modal
    if (btnSair) {
        btnSair.addEventListener('click', (e) => {
            e.preventDefault();
            modal.style.display = 'flex';
        });
    }

    // Fecha ao clicar em cancelar
    if (btnCancel) {
        btnCancel.addEventListener('click', () => {
            modal.style.display = 'none';
        });
    }

    // Fecha ao clicar fora do modal
    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Ação de logout real
    if (btnConfirm) {
        btnConfirm.addEventListener('click', () => {
            window.location.href = 'logout.php'; // Ou o caminho do seu script de logout
        });
    }
});
</script>
    <script src="logout.js"></script>
    <script src="transicao.js"></script>
</body>
</html>