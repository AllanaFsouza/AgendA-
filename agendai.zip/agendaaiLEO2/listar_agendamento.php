<?php
session_start();
require_once 'conexao.php'; // conexão centralizada

header('Content-Type: application/json');

if (!isset($_SESSION['id'])) {
    echo json_encode([]);
    exit;
}

$id_usuario = $_SESSION['id'];

$sql = "SELECT * FROM agendamentos_cliente 
        WHERE id_usuario = ?
        ORDER BY data_agendamento DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();

$result = $stmt->get_result();

$dados = [];

while ($row = $result->fetch_assoc()) {
    $dados[] = $row;
}

// Fechar statement (opcional)
$stmt->close();

echo json_encode($dados);
?>
