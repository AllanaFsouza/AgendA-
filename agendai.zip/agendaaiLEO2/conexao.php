<?php
// conexao.php - conexão centralizada com o banco de dados
$host = "sql112.infinityfree.com";
$user = "if0_41450589";
$pass = "Ditina9008";
$db   = "if0_41450589_root"; // <-- corrigido aqui

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}
?>