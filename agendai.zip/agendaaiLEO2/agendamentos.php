<?php
session_start();
$nome_usuario = $_SESSION['empresa_nome'] ?? 'Admin';
$email_usuario = $_SESSION['empresa_email'] ?? 'admin@gmail.com';

// INCLUIR CONEXÃO
require 'conexao.php';  // <-- substitui o bloco de conexão manual

$sqlFaturamento = "
    SELECT SUM(s.preco) as total
    FROM agendamentos_cliente a
    JOIN servicos s ON a.servicos = s.nome
    WHERE a.status = 'concluido'
";

$resultFaturamento = $conn->query($sqlFaturamento);

if ($resultFaturamento && $rowFat = $resultFaturamento->fetch_assoc()) {
    $faturamento = $rowFat['total'] ?? 0;
}

// BUSCAR AGENDAMENTOS (ORDENADO POR DATA E HORA)
$sql = "SELECT a.*, u.nome 
        FROM agendamentos_cliente a
        JOIN cadastro_usuario u ON a.id_usuario = u.id
        ORDER BY data_agendamento ASC, horario ASC";

$result = $conn->query($sql);

// CONTADORES (cards)
$totalSemana = 0;
$totalCancelados = 0;

$hoje = date('Y-m-d');
$agendamentos = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $agendamentos[] = $row;

        if (date('W', strtotime($row['data_agendamento'])) == date('W')) {
            $totalSemana++;
        }

        if ($row['status'] == 'cancelado') {
            $totalCancelados++;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sua Empresa | Agendamentos</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background: #e5e5e5;
            overflow: hidden;
        }

        /* --- SIDEBAR PADRONIZADA --- */
        .sidebar {
            width: 280px;
            background: #1b1f4b;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
        }

        .logo {
            padding: 25px 20px;
            font-weight: 800;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .menu {
            flex: 1;
            padding: 10px 0;
        }

        .menu-title {
            padding: 15px 20px 5px 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.5;
            font-weight: 600;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
        }

        .menu a i {
            width: 20px;
            text-align: center;
            font-size: 16px;
        }

        .menu a:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .menu a.active {
            background: #4e63ff;
            font-weight: 600;
        }

        /* RODAPÉ DO USUÁRIO NA SIDEBAR */
        .sidebar-footer {
            padding: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .user-info-box {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info-box i {
            background: white;
            color: #1b1f4b;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .user-details {
            display: flex;
            flex-direction: column;
        }

        .user-details strong {
            font-size: 13px;
            display: block;
        }

        .user-details span {
            font-size: 11px;
            opacity: 0.7;
        }

        .logout-btn {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            opacity: 0.8;
            transition: 0.2s;
        }

        .logout-btn:hover {
            opacity: 1;
        }

        /* --- CONTEÚDO --- */
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .page-header {
            background: white;
            padding: 20px 30px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-text h1 { font-size: 20px; color: #333; }
        .header-text p { font-size: 12px; color: #777; }

        .notification-icon {
            width: 35px;
            height: 35px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #555;
            cursor: pointer;
        }

        .page-body {
            padding: 30px;
        }

        /* DASHBOARD CARDS */
        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.03);
            border: 1px solid #eee;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            background: #f0f2f5;
            color: #1b1f4b;
        }

        .stat-info strong { font-size: 22px; color: #1b1f4b; display: block; }
        .stat-info span { font-size: 12px; color: #888; }

        /* LISTA DE AGENDAMENTOS */
        .schedule-card {
            background: #f9f9f9;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
        }

        .schedule-title { font-size: 18px; color: #1b1f4b; font-weight: 700; margin-bottom: 5px; }
        .schedule-sub { font-size: 12px; color: #888; margin-bottom: 25px; }

        .appointment {
            background: white;
            border-radius: 12px;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 12px;
            border: 1px solid #eee;
        }

        .app-left { display: flex; align-items: center; gap: 20px; }

        .time {
            background: #f0f2f5;
            padding: 8px 12px;
            border-radius: 8px;
            text-align: center;
            min-width: 85px;
        }

        .time strong { display: block; font-size: 13px; color: #1b1f4b; }
        .time span { font-size: 10px; color: #777; }

        .client-info strong { font-size: 15px; color: #333; display: block; }
        .client-info span { font-size: 12px; color: #888; }

        /* STATUS TAGS */
        .status {
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .confirmado { background: #e9f7ef; color: #27ae60; }
        .pendente { background: #fff8e5; color: #f39c12; }
        .cancelado { background: #fdeded; color: #e74c3c; }

        /* Remova o border-bottom desta classe se você o tiver adicionado */
.menu-title {
    padding: 15px 20px 5px 20px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    opacity: 0.5;
    font-weight: 600;
    border-bottom: none; /* Garante que não tenha borda aqui */
}

/* Adicione esta regra para a linha abaixo do logo */
.logo {
    padding: 25px 20px;
    font-weight: 800;
    font-size: 18px;
    display: flex;
    align-items: center;
    gap: 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08); /* A linha fina abaixo do logo */
}
:root {
  --cor-tema: #6C63FF;
}
body {
  display: flex;
  height: 100vh;
  background: #e5e5e5;
  overflow: hidden; /* <- isso impede rolagem e pode interferir */
}
.concluido {
    background: #e8f0fe;
    color: #2d6cdf;
}
.filter-btn {
    padding: 8px 16px;
    border-radius: 10px;
    border: none;
    background: #f1f5f9;
    cursor: pointer;
    font-weight: 600;
    transition: .3s;
}

.filter-btn.active {
    background: #4e63ff;
    color: white;
}

.filter-btn:hover {
    transform: translateY(-2px);
}

    </style>
</head>

<body>

    <aside class="sidebar">
        <div>
          <div class="logo">
    <i class="fa-solid fa-scissors"></i> agendaAi
</div>

            <nav class="menu">
                <div class="menu-title">Editar site</div>
                <a href="dashboardadmin.php"><i class="fa-solid fa-chart-line"></i> Dashboard Inicial</a>
                <a href="previsualizacao_cliente.php"><i class="fa-regular fa-eye"></i> Pré-visualização</a>
                <a href="informacoes.php"><i class="fa-solid fa-circle-info"></i> Informações</a>
                <a href="editardadosEmpresa.php"><i class="fa-solid fa-id-card"></i> Dados da Empresa</a>

                <div class="menu-title">Gerenciar</div>
                <a href="servicos.php"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</a>
                <a href="equipe.php"><i class="fa-solid fa-users"></i> Equipe</a>
                <a href="#" class="active"><i class="fa-regular fa-calendar-check"></i> Agendamentos</a>
                <a href="clientes.php"><i class="fa-solid fa-user-group"></i> Clientes</a>
            </nav>
        </div>

        <div class="sidebar-footer">
            <div class="user-info-box">
                <i class="fa-solid fa-user"></i>
                <div class="user-details">
    <strong><?php echo htmlspecialchars($nome_usuario); ?></strong>
    <span><?php echo htmlspecialchars($email_usuario); ?></span>
</div>

            </div>
            <a href="#" class="logout-btn" id="sidebarLogout">
                <i class="fa-solid fa-right-from-bracket"></i> Sair
            </a>
        </div>
    </aside>

    <main class="content">
        <header class="page-header">
            <div class="header-text">
                <h1>Agendamentos</h1>
                <p>Visualize e gerencie os agendamentos</p>
            </div>
            <div class="notification-icon">
                <i class="fa-solid fa-bell"></i>
            </div>
        </header>

        <div class="page-body">

            <!-- CARDS -->
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fa-solid fa-calendar-week"></i>
                    </div>
                    <div class="stat-info">
                        <strong><?php echo $totalSemana; ?></strong>
                        <span>Semana Atual</span>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="color: #27ae60;">
                        <i class="fa-solid fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-info">
                     <strong>R$ <?php echo number_format($faturamento, 2, ',', '.'); ?></strong>

                        <span>Faturamento</span>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="color: #e74c3c;">
                        <i class="fa-solid fa-calendar-xmark"></i>
                    </div>
                    <div class="stat-info">
                        <strong><?php echo $totalCancelados; ?></strong>

                        <span>Cancelamentos</span>
                    </div>
                </div>
            </div>

            <!-- AGENDAMENTOS -->
<div class="schedule-card">

    <div class="schedule-title">Todos os Agendamentos</div>

    <div class="schedule-sub">
        Seu estabelecimento tem <?php echo count($agendamentos); ?> agendamentos no total
    </div>

    <!-- 🔥 FILTROS -->
    <div style="display:flex; gap:10px; margin-bottom:20px;">
        <button class="filter-btn active" onclick="filtrar('todos', this)">Todos</button>
        <button class="filter-btn" onclick="filtrar('ativo', this)">Ativos</button>
        <button class="filter-btn" onclick="filtrar('cancelado', this)">Cancelados</button>
        <button class="filter-btn" onclick="filtrar('concluido', this)">Concluídos</button>
    </div>

    <?php if (count($agendamentos) > 0): ?>

        <?php foreach ($agendamentos as $ag): ?>

            <?php
            $status = $ag['status'];

            $classeStatus = '';
            $textoStatus = '';

            if ($status == 'ativo') {
                $classeStatus = 'confirmado';
                $textoStatus = 'Ativo';

            } else if ($status == 'cancelado') {
                $classeStatus = 'cancelado';
                $textoStatus = 'Cancelado';

            } else if ($status == 'concluido') {
                $classeStatus = 'concluido';
                $textoStatus = 'Concluído';
            }
            ?>

            <!-- 🔥 IMPORTANTE: data-status -->
            <div class="appointment" data-status="<?php echo $status; ?>">

                <div class="app-left">
                    <div class="time">
                        <strong><?php echo date("H:i", strtotime($ag['horario'])); ?>h</strong>
                        <span><?php echo date("d/m/Y", strtotime($ag['data_agendamento'])); ?></span>
                    </div>

                    <div class="client-info">
                        <strong><?php echo htmlspecialchars($ag['nome']); ?></strong>
                        <span>
                            <?php echo htmlspecialchars($ag['servicos']); ?> • 
                            <?php echo ucfirst($ag['categoria']); ?>
                        </span>
                    </div>
                </div>

                <div class="status <?php echo $classeStatus; ?>">
                    <?php echo $textoStatus; ?>
                </div>

            </div>

        <?php endforeach; ?>

    <?php else: ?>

        <p style="margin-top:10px; color:#777;">
            Nenhum agendamento encontrado.
        </p>

    <?php endif; ?>

</div>

        </div>
    </main>
<script>
    function filtrar(status, botao){
    const itens = document.querySelectorAll(".appointment");

    itens.forEach(item => {
        const itemStatus = item.getAttribute("data-status");

        if(status === "todos" || itemStatus === status){
            item.style.display = "flex";
        } else {
            item.style.display = "none";
        }
    });

    // atualizar botão ativo
    document.querySelectorAll(".filter-btn").forEach(btn => {
        btn.classList.remove("active");
    });

    botao.classList.add("active");
}
</script>


    <script src="logout.js"></script>
    <script src="transicao.js"></script>
</body>
</html>