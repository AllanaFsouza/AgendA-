<?php
session_start();
header('Content-Type: application/json');

// ID da empresa (pode vir da sessão ou do login)
$empresa_id = 15; // exemplo fixo, ou $_SESSION['empresa_id']

// INCLUIR CONEXÃO
require 'conexao.php'; // <-- usa a conexão centralizada

// Preparar e executar SQL
$sql = "SELECT data FROM dias_suspensos WHERE empresa_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $empresa_id);
$stmt->execute();
$result = $stmt->get_result();

$dias = [];
while($row = $result->fetch_assoc()){
    $dias[] = $row['data'];
}

echo json_encode($dias);
?>
