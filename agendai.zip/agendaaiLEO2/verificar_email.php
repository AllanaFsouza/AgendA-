<?php
// INCLUIR CONEXÃO
require_once "conexao.php"; // conexão centralizada

$email = $_POST['email'] ?? '';
$senha = trim($_POST['senha'] ?? '');

if (!$email || !$senha) {
    echo "dados_incompletos";
    exit;
}

$sql = "SELECT * FROM cadastro_empresa WHERE email = ?";
$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {

        $empresa = $resultado->fetch_assoc();

        if (password_verify($senha, $empresa['senha'])) {
            echo "Login OK";
        } else {
            echo "Senha incorreta";
        }

    } else {
        echo "Email não encontrado";
    }

    $stmt->close(); // ✅ fechar statement
} else {
    echo "Erro no prepare: " . $conn->error;
}

// ✅ não fecha $conn, vem do conexao.php
?>
