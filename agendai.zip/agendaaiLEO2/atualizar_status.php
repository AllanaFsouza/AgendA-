<?php
// Incluir conexão
require 'conexao.php'; // <-- aqui você centraliza a conexão

// Receber dados do POST
$id = $_POST['id'];
$ativo = $_POST['ativo'];

// Preparar e executar SQL
$sql = "UPDATE servicos SET ativo = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $ativo, $id);

if($stmt->execute()){
    echo "ok";
}else{
    echo "erro";
}

// Fechar statement (não fecha a conexão, pois ela vem do conexao.php)
$stmt->close();
?>
