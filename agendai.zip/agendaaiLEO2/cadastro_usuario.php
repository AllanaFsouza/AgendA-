<?php
require_once "conexao.php"; // <-- usa a conexão centralizada

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    // Criptografar senha
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

    // Verifica se já existe email
    $check = $conn->prepare("SELECT id FROM cadastro_usuario WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo "email_existente";
        exit;
    }

    // Inserir no banco
    $stmt = $conn->prepare("INSERT INTO cadastro_usuario (nome, email, senha) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nome, $email, $senhaHash);

    if ($stmt->execute()) {
        echo "sucesso";
    } else {
        echo "erro";
    }

    $stmt->close();
    $check->close();
}

// Não fechamos $conn, ele vem de conexao.php e pode ser usado em outros scripts
?>
