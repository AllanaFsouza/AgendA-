<?php
session_start();

// INCLUIR CONEXÃO
require 'conexao.php'; // <-- usa a conexão centralizada

$id_empresa = 15; // depois você pode pegar da sessão, ex: $_SESSION['empresa_id']

$sql = "SELECT horarios_disponiveis FROM informacoes_loja WHERE empresa_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_empresa);
$stmt->execute();

$result = $stmt->get_result();
$dados = $result->fetch_assoc();

if($dados && $dados['horarios_disponiveis']){
    echo $dados['horarios_disponiveis']; // já é JSON
} else {
    echo json_encode([]);
}
?>
