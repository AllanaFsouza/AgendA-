<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

$id = $_POST['id'] ?? 0;
$empresa_id = $_SESSION['empresa_id'] ?? 0;

if ($id && $empresa_id) {
    $sql = "DELETE FROM dias_suspensos WHERE id = ? AND empresa_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $empresa_id);
    $stmt->execute();
    $stmt->close(); // Fechar statement
}

header("Location: informacoes.php");
exit;
?>
