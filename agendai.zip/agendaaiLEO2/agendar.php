<!-- PÁGINA DO CLIENTE -->
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empresa | Agendar</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root { --cor-tema: #6C63FF; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
        body { background: #f9fafb; color: #2d3748; line-height: 1.5; min-height: 100vh; overflow-x: hidden; width: 100%; }

        /* --- HEADER PADRONIZADO (IGUAL À PÁGINA INÍCIO) --- */
        header { background: var(--cor-tema); color: white; padding: 15px 20px; position: sticky; top: 0; z-index: 1000; }
        .header-content { display: flex; justify-content: space-between; align-items: center; max-width: 100%; margin: 0; }
        .logo-header { font-size: 20px; font-weight: 700; display: flex; align-items: center; gap: 10px; }

        nav { display: flex; gap: 10px; }
        .nav-button { background: #fff; color: var(--cor-tema); border: none; border-radius: 12px; padding: 8px 18px; cursor: pointer; font-weight: 700; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; font-size: 14px; transition: .3s; }
        .nav-button:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,.15); }
        .nav-button.active { background: var(--cor-tema); color: #fff; border: 1px solid rgba(255,255,255,0.3); }

        .header-user { display: flex; flex-direction: column; align-items: center; gap: 4px; }
        .perfil-icon { background: white; color: var(--cor-tema); border: none; width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 16px; transition: .3s; }
        .perfil-icon:hover { transform: scale(1.08); }
        .logout-header { font-size: 12px; text-decoration: none; color: white; opacity: .9; font-weight: 600; cursor: pointer; }

        /* --- HERO E CONTEÚDO --- */
        .hero { background: var(--cor-tema); color: white; padding: 60px 20px 100px 20px; text-align: center; }
        .hero h1 { font-size: 2.2rem; font-weight: 800; }

        .main { max-width: 1400px; margin: -60px auto 40px auto; padding: 0 20px; }
        .layout-grid { display: grid; grid-template-columns: 1fr 1fr 1.6fr; gap: 15px; align-items: start; }
        .section { background: white; padding: 20px; border-radius: 24px; box-shadow: 0 10px 25px rgba(0,0,0,.06); }

        /* Estilos dos Cards e Calendário */
        .grid { display: grid; grid-template-columns: 1fr; gap: 12px; }
        .card-selection { background: #f8fafc; padding: 15px; border-radius: 18px; text-align: center; border: 2px solid transparent; cursor: pointer; transition: 0.2s; display: flex; align-items: center; gap: 10px; }
        .card-selection.selected { border-color: var(--cor-tema); background: #f0f0ff; color: var(--cor-tema); font-weight: 600; }

        .calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 6px; }
        .day, .time { background: #f1f5f9; padding: 10px; border-radius: 12px; text-align: center; cursor: pointer; font-weight: 600; font-size: 0.8rem; }
        .day.selected, .time.selected { background: var(--cor-tema); color: white; }
        .day.disabled { opacity: 0.3; text-decoration: line-through; pointer-events: none; }

        /* Relatório e Botão */
        .footer-container { grid-column: 1 / span 3; display: flex; gap: 20px; align-items: stretch; margin-top: 10px; }
        .summary-report { flex: 1.5; background: #fff; border-left: 6px solid var(--cor-tema); padding: 25px; border-radius: 24px; box-shadow: 0 10px 25px rgba(0,0,0,.06); }
        .summary-item { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f1f5f9; }
        .summary-item span:last-child { font-weight: 700; color: var(--cor-tema); }

        .btn-confirmar-agendamento { flex: 1; background: var(--cor-tema); color: white; border: none; border-radius: 24px; font-size: 1.3rem; font-weight: 800; cursor: pointer; transition: 0.3s; box-shadow: 0 10px 20px rgba(108,99,255,0.3); }
        .btn-confirmar-agendamento:disabled { background: #cbd5e1; cursor: not-allowed; box-shadow: none; opacity: 0.6; }

        /* Modais */
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.45); backdrop-filter: blur(4px); z-index: 1000; align-items: center; justify-content: center; }
        .modal-content { background: white; width: 420px; border-radius: 20px; padding: 35px; position: relative; border: 2px solid var(--cor-tema); box-shadow: 0 25px 60px rgba(0,0,0,0.25); }
        
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .animar-entrada { display: block !important; animation: fadeInUp 0.5s ease-out forwards; }
        .modal-saindo { animation: modalSaida .3s ease forwards; }
        @keyframes modalSaida { from { opacity: 1; transform: translateY(0) scale(1); } to { opacity: 0; transform: translateY(20px) scale(.9); } }
    
        .close-btn { position: absolute; top: 15px; right: 18px; font-size: 20px; cursor: pointer; color: #999; transition: .3s; }
    .close-btn:hover { color: #ff4d4d; }
    
    .perfil-form { display: flex; flex-direction: column; gap: 12px; margin-top: 15px; text-align: left; }
    .perfil-form label { font-size: 13px; font-weight: 700; color: #444; margin-bottom: -5px; }
    .perfil-form input { padding: 12px; border-radius: 10px; border: 1px solid #ddd; outline: none; transition: .3s; }
    .perfil-form input:focus { border-color: var(--cor-tema); box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.1); }
    
    .cor-area { display: flex; align-items: center; gap: 10px; margin-top: 5px; }
    .cor-preview { width: 40px; height: 40px; border-radius: 10px; border: 2px solid #eee; }
    
    .paleta-cores { display: none; margin-top: 10px; background: #f9f9f9; padding: 12px; border-radius: 15px; grid-template-columns: repeat(3, 1fr); gap: 10px; border: 1px solid #eee; }
    .paleta-cores div { height: 30px; border-radius: 8px; cursor: pointer; transition: .2s; }
    .paleta-cores div:hover { transform: scale(1.1); }
    
    .btn-primario { background: var(--cor-tema); color: white; border: none; padding: 14px; border-radius: 14px; font-weight: 700; cursor: pointer; margin-top: 10px; transition: .3s; }
    .btn-primario:hover { filter: brightness(1.1); transform: translateY(-2px); }
    .btn-secundario { background: #f1f5f9; border: none; padding: 12px; border-radius: 14px; cursor: pointer; font-weight: 600; color: #64748b; transition: .3s; }
    .btn-secundario:hover { background: #e2e8f0; }

    /* Estilo para o Modal de Logout */
    .modal-logout { text-align: center; }
    .logout-botoes { display: flex; gap: 10px; margin-top: 25px; }
    .btn-confirmar { flex: 1; background: #e74c3c; color: white; border: none; padding: 12px; border-radius: 10px; cursor: pointer; font-weight: 700; }
    .btn-cancelar { flex: 1; background: #eee; border: none; padding: 12px; border-radius: 10px; cursor: pointer; font-weight: 600; }
@keyframes modalSaida { from { opacity: 1; transform: translateY(0) scale(1); } to { opacity: 0; transform: translateY(20px) scale(.9); } }
@keyframes modalEntrada { from { opacity: 0; transform: translateY(20px) scale(.95); } to { opacity: 1; transform: translateY(0) scale(1); } }
@keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
.perfil-dado {
    padding: 12px;
    border-radius: 10px;
    background: #f1f5f9;
    border: 1px solid #ddd;
    font-weight: 500;
}
</style>
</head>
<body>

<header>
    <div class="header-content">
        <div class="logo-header"><i class="fa-solid fa-scissors"></i>Empresa</div>

        <nav>
            <a href="dashboardcliente.php" class="nav-button active">Início</a>
            <a href="agendar.php" class="nav-button active">Agendar</a>
            <a href="meus.php" class="nav-button active">Meus</a>
        </nav>

        <div class="header-user">
            <button class="perfil-icon" onclick="abrirPerfilModal()"><i class="fa-solid fa-user"></i></button>
            <a class="logout-header" onclick="abrirModalLogout()">Sair</a>
        </div>
    </div>
</header>

<section class="hero">
    <p>Agendamento online</p>
    <h1>Escolha seu serviço ✂️</h1>
</section>

<div class="main">
    <div class="layout-grid">
        <div class="section">
            <h3><i class="fa-solid fa-layer-group"></i> 1. Categoria</h3>
            <div class="grid" id="categories">
                <div class="card-selection" onclick="selectCategory(this, 'masculino')"><i class="fa-solid fa-person"></i> Masculino</div>
                <div class="card-selection" onclick="selectCategory(this, 'feminino')"><i class="fa-solid fa-person-dress"></i> Feminino</div>

            </div>
        </div>

        <div class="section" id="servicesSection" style="display:none;">
            <h3><i class="fa-solid fa-check-to-slot"></i> 2. Serviço</h3>
            <div class="grid" id="services"></div>
        </div>

        <div class="section" id="calendarSection" style="display:none;">
            <h3><i class="fa-solid fa-calendar-day"></i> 3. Data e horário</h3>
            <div class="calendar-grid" id="calendar"></div>
            <div class="grid" style="margin-top:15px;" id="times"></div>
        </div>

        <!-- MODAL PERFIL -->
<div class="modal-overlay" id="modalPerfil">
    <div class="modal-content">
        <span class="close-btn" onclick="fecharPerfilModal()">&times;</span>
        <h2 style="display:flex; align-items:center; gap:10px;"><i class="fa-solid fa-circle-user" style="color:var(--cor-tema)"></i> Meu Perfil</h2>
        <div class="perfil-form">
    <label>Nome Completo</label>
    <div class="perfil-dado"><?php echo $_SESSION['nome'] ?? 'Não definido'; ?></div>
    
    <label>E-mail</label>
    <div class="perfil-dado"><?php echo $_SESSION['email'] ?? 'Não definido'; ?></div>
</div>
    </div>
</div>

<div class="modal-overlay" id="modalLogout">
    <div class="modal-content modal-logout">
        <h2><i class="fa-solid fa-right-from-bracket"></i> Sair</h2>
        <p style="margin-top:10px; color:#666;">Tem certeza que deseja encerrar sua sessão?</p>
        <div class="logout-botoes">
            <button class="btn-cancelar" onclick="fecharComAnimacao('modalLogout')">Cancelar</button>
            <button class="btn-confirmar" onclick="confirmarLogout()">Sim, sair</button>
        </div>
    </div>
</div>


        <div class="footer-container">
            <div class="summary-report" id="summary">
                <h3 style="margin-bottom: 10px;"><i class="fa-solid fa-file-lines"></i> Relatório do Agendamento</h3>
                <div class="summary-item"><span>Categoria selecionada:</span> <span id="sCategory">-</span></div>
                <div class="summary-item"><span>Serviços escolhidos:</span> <span id="sService">-</span></div>
                <div class="summary-item"><span>Data:</span> <span id="sDate">-</span></div>
                <div class="summary-item"><span>Horário:</span> <span id="sTime">-</span></div>
                <div class="summary-item">
    <span>Total:</span> 
    <span id="sPreco">-</span>
</div>

            </div>

            <button class="btn-confirmar-agendamento" id="confirmBtn" disabled onclick="confirmarAgendamento()">
                CONFIRMAR AGENDAMENTO
            </button>
        </div>
    </div>
</div>

<script>
    // Lógica de agendamento original
   

    let selectedCategory = null;
    let selectedServices = [];
let totalPreco = 0;

    let selectedDate = null;
    let selectedTime = null;

   function selectCategory(el, cat) {
    document.querySelectorAll('#categories .card-selection')
        .forEach(x => x.classList.remove('selected'));

    el.classList.add('selected');

    selectedCategory = cat;
    selectedServices = [];
    selectedDate = null;
    selectedTime = null;

    const sDiv = document.getElementById('services');
    sDiv.innerHTML = "Carregando...";

    // 🔥 BUSCAR DO BANCO
    fetch(`buscar_servicos.php?categoria=${cat}`)
    .then(res => res.json())
    .then(data => {

        if(data.length === 0){
            sDiv.innerHTML = "<p>Nenhum serviço disponível</p>";
            return;
        }

      sDiv.innerHTML = data.map(s => `
    <div class="card-selection" 
        onclick="selectService(this, '${s.nome}', ${s.preco})">
        ${s.nome}
    </div>
`).join('');


        document.getElementById('servicesSection').classList.add('animar-entrada');
    });

    updateSummary();
    carregarDiasSuspensos();
}

function selectService(el, nome, preco) {

    // Remove seleção de todos os serviços
    document.querySelectorAll('#services .card-selection')
        .forEach(x => x.classList.remove('selected'));

    // Seleciona o clicado
    el.classList.add('selected');

    // Define apenas UM serviço
    selectedServices = [{ nome, preco }];
    totalPreco = preco;

    // Libera calendário
    document.getElementById('calendarSection').classList.add('animar-entrada');
    renderCalendar();

    updateSummary();
}

let diasSuspensos = [];

// Buscar dias suspensos ao selecionar categoria ou ao carregar calendário
function carregarDiasSuspensos() {
    fetch('buscar_dias_suspensos.php')
    .then(res => res.json())
    .then(data => {
        diasSuspensos = data;
        renderCalendar();
    })
    .catch(() => {
        diasSuspensos = [];
    });
}

function renderCalendar() {
    const cal = document.getElementById('calendar');
    cal.innerHTML = '';

    const hoje = new Date();
    const mes = hoje.getMonth() + 1; // Março = 3
    const ano = hoje.getFullYear();

    for (let i = 1; i <= 30; i++) {
        const dia = new Date(ano, mes - 1, i);
        const diaStr = dia.toISOString().split('T')[0]; // YYYY-MM-DD

        const d = document.createElement('div');
        d.className = 'day';
        d.innerText = i;

        // Bloquear dias antes de hoje ou dias suspensos
        if (dia < hoje || diasSuspensos.includes(diaStr)) {
            d.classList.add('disabled');
        } else {
            d.onclick = () => {
                document.querySelectorAll('.day').forEach(x => x.classList.remove('selected'));
                d.classList.add('selected');
                selectedDate = `${i}/03/2026`;
                renderTimes();
                updateSummary();
            };
        }

        cal.appendChild(d);
    }
}


    function renderTimes() {
        const tGrid = document.getElementById('times');
        const horas = ["09:00", "10:30", "14:00", "16:30"];
        tGrid.innerHTML = horas.map(h => `<div class="time" onclick="selectTime(this, '${h}')">${h}</div>`).join('');
    }

    function selectTime(el, h) {
        document.querySelectorAll('.time').forEach(x => x.classList.remove('selected'));
        el.classList.add('selected');
        selectedTime = h;
        updateSummary();
    }

  function updateSummary() {

    document.getElementById('sCategory').innerText = 
        selectedCategory ? selectedCategory.toUpperCase() : "-";

    document.getElementById('sService').innerText = 
        selectedServices.length > 0 
        ? selectedServices.map(s => s.nome).join(", ") 
        : "-";

    document.getElementById('sDate').innerText = selectedDate || "-";
    document.getElementById('sTime').innerText = selectedTime || "-";

    document.getElementById('sPreco').innerText = 
        totalPreco > 0 
        ? "R$ " + totalPreco.toFixed(2).replace(".", ",") 
        : "-";

    const btn = document.getElementById('confirmBtn');

    btn.disabled = !(
        selectedCategory && 
        selectedServices.length > 0 && 
        selectedDate && 
        selectedTime
    );
}


    function confirmarAgendamento() { alert("Agendamento solicitado!"); }

    /* FUNÇÕES DOS MODAIS (PADRONIZADAS) */
    function abrirPerfilModal() { document.getElementById("modalPerfil").style.display="flex"; }
    function abrirModalLogout() { document.getElementById("modalLogout").style.display="flex"; }
    
    function fecharComAnimacao(id) {
        const overlay = document.getElementById(id);
        const modal = overlay.querySelector(".modal-content");
        modal.classList.add("modal-saindo");
        setTimeout(() => {
            overlay.style.display="none";
            modal.classList.remove("modal-saindo");
        }, 300);
    }
    function confirmarAgendamento() {
    // Preenche o pequeno resumo dentro do modal
    const resumo = `${selectedServices.join(", ")} - ${selectedDate} às ${selectedTime}`;
    document.getElementById('resumoFinal').innerText = resumo;
    
    // Abre o modal
    document.getElementById("modalConfirmacao").style.display = "flex";
}

function finalizarProcesso() {

    const dados = new URLSearchParams();
    dados.append("categoria", selectedCategory);
    dados.append(
    "servicos", 
    selectedServices.map(s => s.nome).join(", ")
);


    dados.append("data", selectedDate);
    dados.append("horario", selectedTime);

   fetch("salvar_agendamento.php", {
    method: "POST",
    body: dados,
    credentials: 'include' // 🔥 ISSO AQUI RESOLVE
})
    .then(res => res.json())
    .then(res => {

        if(res.status === "sucesso"){
            fecharComAnimacao('modalConfirmacao');
            setTimeout(() => {
                document.getElementById("modalSucesso").style.display = "flex";
            }, 300);
        }

        else if(res.status === "ocupado"){
            fecharComAnimacao('modalConfirmacao');
            setTimeout(() => {
                document.getElementById("modalErroOcupado").style.display = "flex";
            }, 300);
        }

        else{
            alert("Erro: " + res.msg);
            console.log(res);
        }

    })
    .catch(err => {
        console.error(err);
        alert("Erro na requisição.");
    });
}
// Simulação de banco de dados (Armazena: "DATA|HORARIO")
let agendamentosExistentes = ["19/03/2026|10:30", "20/03/2026|14:00"];

function renderTimes() {
    const tGrid = document.getElementById('times');
    const horas = ["09:00", "10:30", "14:00", "16:30"];
    
    tGrid.innerHTML = horas.map(h => {
        // Verifica se este par Data + Hora já existe no "banco"
        const chaveAgendamento = `${selectedDate}|${h}`;
        const ocupado = agendamentosExistentes.includes(chaveAgendamento);
        
        if (ocupado) {
            return `<div class="time disabled" style="opacity:0.4; cursor:not-allowed; text-decoration:line-through;">${h}</div>`;
        } else {
            return `<div class="time" onclick="selectTime(this, '${h}')">${h}</div>`;
        }
    }).join('');
}

function salvarPerfil() {
        // Aqui você pode adicionar lógica para salvar o nome/email via API
        fecharPerfilModal();
    }
function fecharPerfilModal() {
        fecharComAnimacao("modalPerfil");
    }

    function confirmarLogout() {
        window.location.href = "login_cliente.html"; 
    }

    // Carregar cor ao iniciar a página
    window.addEventListener('DOMContentLoaded', () => {
        let cor = localStorage.getItem("corTemaSite");
        if(cor) {
            document.documentElement.style.setProperty('--cor-tema', cor);
        }
    });
    function fecharComAnimacao(id){
    const overlay = document.getElementById(id);
    const modal = overlay.querySelector(".modal-content");

    modal.classList.add("modal-saindo");

    setTimeout(()=>{
        overlay.style.display="none";
        modal.classList.remove("modal-saindo");
    },300);
}
</script>

<div class="modal-overlay" id="modalErroOcupado">
    <div class="modal-content" style="text-align:center; border-color: #f39c12;">
        <div style="font-size: 60px; color: #f39c12; margin-bottom: 20px;">
            <i class="fa-solid fa-calendar-times"></i>
        </div>
        <h2 style="color: #333;">Horário Indisponível</h2>
        <p style="margin: 15px 0; color: #666; line-height: 1.4;">
            Ops! Alguém acabou de reservar este horário ou ele não está mais disponível. 
            <br><strong>Por favor, escolha outro horário ou data.</strong>
        </p>
        
        <button class="nav-button active" style="width: 100%; justify-content: center; padding: 15px; background: #f39c12;" 
            onclick="fecharComAnimacao('modalErroOcupado')">
            ESCOLHER OUTRO
        </button>
    </div>
</div>
<div class="modal-overlay" id="modalConfirmacao">
    <div class="modal-content" style="text-align:center;">
        <div style="font-size: 50px; color: #27ae60; margin-bottom: 15px;">
            <i class="fa-solid fa-circle-check"></i>
        </div>
        <h2 style="color: #333;">Confirmar Agendamento?</h2>
        <p style="margin: 15px 0; color: #666; font-size: 15px; line-height: 1.4;">
            Você está prestes a agendar seu horário. Deseja prosseguir com a solicitação?
        </p>

        <div style="background: #f8fafc; padding: 15px; border-radius: 15px; text-align: left; margin-bottom: 20px; border: 1px dashed var(--cor-tema);">
            <p style="font-size: 13px; color: #777;">Resumo:</p>
            <p id="resumoFinal" style="font-weight: 700; color: var(--cor-tema); font-size: 14px;"></p>
        </div>

        <div style="display:flex; gap:10px;">
            <button style="flex:1; padding:12px; border:none; border-radius:12px; cursor:pointer; background:#eee; font-weight:600;" 
                onclick="fecharComAnimacao('modalConfirmacao')">Voltar</button>
            <button style="flex:1; padding:12px; border:none; border-radius:12px; cursor:pointer; background:var(--cor-tema); color:white; font-weight:700;" 
                onclick="finalizarProcesso()">Confirmar</button>
        </div>
    </div>
</div>
<div class="modal-overlay" id="modalLogout">
    <div class="modal-content" style="text-align:center;">
        <h2><i class="fa-solid fa-right-from-bracket"></i> Sair</h2>
        <p style="margin-top:10px;color:#666;">Deseja encerrar sua sessão?</p>
        <div style="display:flex;gap:10px;margin-top:25px;">
            <button style="flex:1;padding:12px;border:none;border-radius:10px;cursor:pointer;background:#eee;" onclick="fecharComAnimacao('modalLogout')">Cancelar</button>
            <button style="flex:1;padding:12px;border:none;border-radius:10px;cursor:pointer;background:#e74c3c;color:white;font-weight:700;" onclick="location.href='../loginCadastro_cliente/login_cliente.html'">Sair</button>
        </div>
    </div>
</div>

<script>function abrirPerfilModal(){
document.getElementById("modalPerfil").style.display="flex";
}

function fecharPerfilModal(){
fecharComAnimacao("modalPerfil");
}

function salvarPerfil(){
    fecharPerfilModal();
}
window.onload=()=>{
let cor=localStorage.getItem("corTemaSite");
if(cor){
document.documentElement.style.setProperty('--cor-tema',cor);
document.getElementById("previewCor").style.background=cor;
}
};
function renderTimes() {
    const tGrid = document.getElementById('times');
    tGrid.innerHTML = "Carregando horários...";

    fetch("buscar_horarios.php")
    .then(res => res.json())
    .then(horas => {

        if(!horas || horas.length === 0){
            tGrid.innerHTML = "<p>Nenhum horário disponível</p>";
            return;
        }

        tGrid.innerHTML = horas.map(h => {

            const chaveAgendamento = `${selectedDate}|${h}`;
            const ocupado = agendamentosExistentes.includes(chaveAgendamento);

            if (ocupado) {
                return `
                    <div class="time disabled" 
                        style="opacity:0.4; cursor:not-allowed; text-decoration:line-through;">
                        ${h}
                    </div>
                `;
            } else {
                return `
                    <div class="time" onclick="selectTime(this, '${h}')">
                        ${h}
                    </div>
                `;
            }

        }).join('');
    })
    .catch(() => {
        tGrid.innerHTML = "<p>Erro ao carregar horários</p>";
    });
}
</script>
<script src="transicao.js"></script>
</body>
</html>