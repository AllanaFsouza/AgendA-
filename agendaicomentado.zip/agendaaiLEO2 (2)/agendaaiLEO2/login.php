<!-- inutilizado -->

<?php
// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

if (!$email || !$senha) {
    echo "Email e senha são obrigatórios.";
    exit;
}

/* BUSCA O USUÁRIO NO BANCO */
$sql = "SELECT * FROM cadastro_usuario WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

if($result->num_rows == 1){

    $usuario = $result->fetch_assoc();

    /* VERIFICA A SENHA */
    if(password_verify($senha, $usuario['senha'])){

        // ✅ criar sessão se necessário
        session_start();
        $_SESSION['id'] = $usuario['id'];
        $_SESSION['nome'] = $usuario['nome'];
        $_SESSION['email'] = $usuario['email'];

        header("Location: cliente.html");
        exit();

    } else {
        echo "Senha incorreta.";
    }

} else {
    echo "Email não encontrado.";
}

// Fechar statement (opcional)
$stmt->close();

// Não fechamos $conn, ele vem de conexao.php
?>
