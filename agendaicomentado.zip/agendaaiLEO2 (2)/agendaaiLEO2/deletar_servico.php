<!-- tarbalha com serviços -->

<?php
require_once "conexao.php"; // <-- conexão centralizada

$id = $_POST['id'] ?? 0;

if($id){
    $stmt = $conn->prepare("DELETE FROM servicos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    echo "ok";

    // Fechar statement (opcional)
    $stmt->close();
}

// Não fechamos $conn, ele vem de conexao.php e pode ser usado em outros scripts
?>
