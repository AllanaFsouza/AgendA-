<!-- Trabalha com o código agendar -->

<?php
require_once "conexao.php"; // <-- usa a conexão centralizada

$id = $_POST['id'];

$sql = "UPDATE agendamentos_cliente SET status='cancelado' WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

echo "ok";

// Fechar statement (opcional)
$stmt->close();
?>
