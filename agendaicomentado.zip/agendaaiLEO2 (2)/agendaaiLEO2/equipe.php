<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

$empresa_id = $_SESSION['empresa_id'] ?? 0;

$funcionarios = [];

if ($empresa_id) {
    $sql = "SELECT * FROM funcionarios_empresa WHERE empresa_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $empresa_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $funcionarios[] = $row;
    }

    // Fechar statement (opcional)
    $stmt->close();
}

$nome_usuario = $_SESSION['empresa_nome'] ?? 'Admin';
$email_usuario = $_SESSION['empresa_email'] ?? 'admin@gmail.com';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sua Empresa | Equipes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background: #e5e5e5;
            overflow: hidden;
        }

        /* --- SIDEBAR PADRONIZADA --- */
        .sidebar {
            width: 280px;
            background: #1b1f4b;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
        }

        .logo {
            padding: 25px 20px;
            font-weight: 800;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .menu {
            flex: 1;
            padding: 10px 0;
        }

        .menu-title {
            padding: 15px 20px 5px 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.5;
            font-weight: 600;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
        }

        .menu a i {
            width: 20px;
            text-align: center;
            font-size: 16px;
        }

        .menu a:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .menu a.active {
            background: #4e63ff;
            font-weight: 600;
        }

        /* RODAPÉ DO USUÁRIO NA SIDEBAR */
        .sidebar-footer {
            padding: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .user-info-box {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info-box i {
            background: white;
            color: #1b1f4b;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .user-details {
            display: flex;
            flex-direction: column;
        }

        .user-details strong {
            font-size: 13px;
            display: block;
        }

        .user-details span {
            font-size: 11px;
            opacity: 0.7;
        }

        .logout-btn {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            opacity: 0.8;
            transition: 0.2s;
        }

        .logout-btn:hover {
            opacity: 1;
        }

        /* --- CONTEÚDO --- */
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .page-header {
            background: white;
            padding: 20px 30px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-text h1 { font-size: 20px; color: #333; }
        .header-text p { font-size: 12px; color: #777; }

        .notification-icon {
            width: 35px;
            height: 35px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #555;
            cursor: pointer;
        }

        /* --- CARD DE EQUIPE --- */
        .page-body {
            padding: 40px;
            display: flex;
            justify-content: center;
        }

        .team-card {
            width: 100%;
            max-width: 850px;
            background: #f9f9f9;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
            min-height: 400px;
        }

        .team-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .team-title-group {
            display: flex;
            align-items: flex-start;
            gap: 12px;
        }

        .team-title-group i {
            color: #4e63ff;
            font-size: 20px;
            margin-top: 4px;
        }

        .team-title-text h2 { font-size: 18px; color: #1b1f4b; }
        .team-title-text span { font-size: 12px; color: #888; }

        .add-btn {
            background: #4e63ff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
        }

        .add-btn:hover { background: #3a4ed9; }

        /* LISTA DE MEMBROS */
        .member {
            background: white;
            border-radius: 12px;
            padding: 15px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 12px;
            border: 1px solid #eee;
        }

        .member-left { display: flex; align-items: center; gap: 15px; }
        .avatar { width: 40px; height: 40px; background: #eee; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #aaa; }
        .member-info strong { font-size: 15px; color: #333; display: block; }
        .member-info span { font-size: 12px; color: #888; }

        .member-actions { display: flex; align-items: center; gap: 20px; }
        
        /* SWITCH */
        .switch { position: relative; display: inline-block; width: 40px; height: 20px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; border-radius: 34px; transition: .4s; }
        .slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 2px; bottom: 2px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #4e63ff; }
        input:checked + .slider:before { transform: translateX(20px); }

        .delete-icon { color: #ccc; cursor: pointer; transition: 0.2s; }
        .delete-icon:hover { color: #ff4d4d; }

        /* MODAIS */
        .modal {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal-box {
            background: white;
            width: 400px;
            border-radius: 15px;
            padding: 25px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .modal-header { display: flex; justify-content: space-between; align-items: center; }
        .modal-box input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; margin-top: 5px; }
        .save-btn { background: #4e63ff; color: white; border: none; padding: 12px; border-radius: 8px; cursor: pointer; font-weight: 600; }
    
        /* Remova o border-bottom desta classe se você o tiver adicionado */
.menu-title {
    padding: 15px 20px 5px 20px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    opacity: 0.5;
    font-weight: 600;
    border-bottom: none; /* Garante que não tenha borda aqui */
}

/* Adicione esta regra para a linha abaixo do logo */
.logo {
    padding: 25px 20px;
    font-weight: 800;
    font-size: 18px;
    display: flex;
    align-items: center;
    gap: 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08); /* A linha fina abaixo do logo */
}
:root {
  --cor-tema: #6C63FF;
}
body {
  display: flex;
  height: 100vh;
  background: #e5e5e5;
  overflow: hidden; /* <- isso impede rolagem e pode interferir */
}

    </style>
</head>
<body>

    <aside class="sidebar">
        <div>
                <div class="logo">
    <i class="fa-solid fa-scissors"></i> agendaAi
</div>

            <nav class="menu">
                <div class="menu-title">Editar site</div>
                <a href="dashboardadmin.php"><i class="fa-solid fa-chart-line"></i> Dashboard Inicial</a>
                <a href="previsualizacao_cliente.php"><i class="fa-regular fa-eye"></i> Pré-visualização</a>
                <a href="informacoes.php"><i class="fa-solid fa-circle-info"></i> Informações</a>
<a href="editardadosEmpresa.php"><i class="fa-solid fa-id-card"></i> Dados da Empresa</a>
                <div class="menu-title">Gerenciar</div>
                <a href="servicos.php"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</a>
                <a href="#" class="active"><i class="fa-solid fa-users"></i> Equipe</a>
                <a href="agendamentos.php"><i class="fa-regular fa-calendar-check"></i> Agendamentos</a>
                <a href="clientes.php"><i class="fa-solid fa-user-group"></i> Clientes</a>
              
            </nav>
        </div>

        <div class="sidebar-footer">
            <div class="user-info-box">
                <i class="fa-solid fa-user"></i>
<div class="user-details">
    <strong><?php echo htmlspecialchars($nome_usuario); ?></strong>
    <span><?php echo htmlspecialchars($email_usuario); ?></span>
</div>
            </div>
            <a href="#" class="logout-btn" id="sidebarLogout">
                <i class="fa-solid fa-right-from-bracket"></i> Sair
            </a>
        </div>
    </aside>

    <main class="content">
        <header class="page-header">
            <div class="header-text">
                <h1>Equipe</h1>
                <p>Gerencie os profissionais do salão</p>
            </div>
            <div class="notification-icon">
                <i class="fa-solid fa-bell"></i>
            </div>
        </header>

        <div class="page-body">
            <div class="team-card">
                <div class="team-header">
                    <div class="team-title-group">
                        <i class="fa-solid fa-users"></i>
                        <div class="team-title-text">
                            <h2>Membros da Equipe</h2>
                            <span id="contadorEquipe">0 ativos de 0 membros</span>
                        </div>
                    </div>
                    <button class="add-btn" id="openModal">+ Adicionar</button>
                </div>

               <div id="listaMembros">
<?php foreach ($funcionarios as $f): ?>
    <div class="member">
        <div class="member-left">
            <div class="avatar"><i class="fa-solid fa-user"></i></div>
            <div class="member-info">
                <strong><?php echo htmlspecialchars($f['nome']); ?></strong>
                <span><?php echo htmlspecialchars($f['funcao']); ?></span>
            </div>
        </div>
        <div class="member-actions">
            <label class="switch">
                <input 
    type="checkbox" 
    <?php echo $f['ativo'] ? 'checked' : ''; ?>
    onchange="toggleAtivo(<?php echo $f['id']; ?>, this.checked)"
>

                <span class="slider"></span>
            </label>
           <i class="fa-solid fa-trash delete-icon" onclick="removerMembro(this, <?php echo $f['id']; ?>)"></i>

        </div>
    </div>
<?php endforeach; ?>
</div>

            </div>
        </div>
    </main>

    <div id="modalFuncionario" class="modal">
        <div class="modal-box">
            <div class="modal-header">
                <h2>Novo Funcionário</h2>
                <i class="fa-solid fa-xmark" style="cursor:pointer" onclick="fecharModal()"></i>
            </div>
            <form id="formFuncionario">
                <label>Nome</label>
                <input id="nomeFuncionario" type="text" placeholder="Nome do funcionário" required>
                <label>Função</label>
                <input id="funcaoFuncionario" type="text" placeholder="Ex: Barbeiro" required>
                <button type="submit" class="save-btn">Salvar Funcionário</button>
            </form>
        </div>
    </div>

    <script>

const modal = document.getElementById("modalFuncionario");
const btnAdicionar = document.getElementById("openModal");
const form = document.getElementById("formFuncionario");
const listaMembros = document.getElementById("listaMembros");

btnAdicionar.onclick = () => modal.style.display = "flex";

function fecharModal() {
    modal.style.display = "none";
}

window.onclick = (e) => {
    if(e.target == modal) fecharModal();
};

// ENVIAR PARA O BANCO
form.onsubmit = (e) => {
    e.preventDefault();

    const nome = document.getElementById("nomeFuncionario").value;
    const funcao = document.getElementById("funcaoFuncionario").value;

    fetch("salvar_funcionario.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `nome=${encodeURIComponent(nome)}&funcao=${encodeURIComponent(funcao)}`
    })
    .then(res => res.text())
    .then(resposta => {

        if(resposta === "ok"){
            // adiciona na tela depois de salvar
            criarFuncionarioNaTela(nome, funcao);

            form.reset();
            fecharModal();
        } else {
            alert("Erro ao salvar no banco");
        }

    });
};

// CRIAR FUNCIONÁRIO NA TELA
function criarFuncionarioNaTela(nome, funcao){
    const div = document.createElement("div");
    div.className = "member";

    div.innerHTML = `
        <div class="member-left">
            <div class="avatar"><i class="fa-solid fa-user"></i></div>
            <div class="member-info">
                <strong>${nome}</strong>
                <span>${funcao}</span>
            </div>
        </div>
        <div class="member-actions">
            <label class="switch">
                <input type="checkbox" checked onchange="atualizarContador()">
                <span class="slider"></span>
            </label>
            <i class="fa-solid fa-trash delete-icon" onclick="removerMembro(this)"></i>
        </div>
    `;

    listaMembros.appendChild(div);
    atualizarContador();
}

function removerMembro(el, id) {
    if(confirm("Deseja remover este membro?")) {

        fetch("deletar_funcionario.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: `id=${id}`
        })
        .then(res => res.text())
        .then(res => {
            if(res === "ok"){
                el.closest(".member").remove();
                atualizarContador();
            } else {
                alert("Erro ao deletar");
            }
        });

    }
}


// CONTADOR
function atualizarContador() {
    const total = document.querySelectorAll(".member").length;
    const ativos = document.querySelectorAll(".member input:checked").length;

    document.getElementById("contadorEquipe").textContent =
        `${ativos} ativos de ${total} membros`;
}
function toggleAtivo(id, ativo) {

    fetch("toggle_funcionario.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: `id=${id}&ativo=${ativo ? 1 : 0}`
    })
    .then(res => res.text())
    .then(res => {
        if(res !== "ok"){
            alert("Erro ao atualizar status");
        }
    });

}
window.onload = () => {
    atualizarContador();
};

</script>
        <script src="logout.js"></script>
        <script src="transicao.js"></script>
</body>
</html>