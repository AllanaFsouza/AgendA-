// 1. Criar estilos
const style = document.createElement('style');
style.innerHTML = `
    html, body {
        margin: 0;
        padding: 0;
        overflow-x: hidden;
    }

    /* Overlay mais suave */
    .fade-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #a29bfe; /* roxo */
        z-index: 99999;
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.8s ease; /* mais suave */
    }

    .fade-overlay.active {
        opacity: 0.25; /* bem leve */
    }

    /* Entrada suave */
    body {
        opacity: 0;
        transition: opacity 0.8s ease;
    }

    body.loaded {
        opacity: 1;
    }
`;
document.head.appendChild(style);

// 2. Criar overlay
const overlay = document.createElement('div');
overlay.className = 'fade-overlay';
document.body.appendChild(overlay);

// 3. Quando a página carrega → fade-in
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
});

// 4. Interceptar cliques
document.addEventListener('DOMContentLoaded', () => {
    const links = document.querySelectorAll(
        'a:not([href^="#"]):not([target="_blank"]):not([onclick])'
    );

    links.forEach(link => {
        link.addEventListener('click', (e) => {
            const destination = link.href;

            if (
                destination &&
                destination !== window.location.href &&
                !destination.includes('javascript:') &&
                new URL(destination).origin === window.location.origin
            ) {
                e.preventDefault();

                // ativa overlay suave
                overlay.classList.add('active');

                // leve delay mais natural
                setTimeout(() => {
                    window.location.href = destination;
                }, 600);
            }
        });
    });
});

// 5. Corrigir voltar do navegador
window.onpageshow = function (event) {
    if (event.persisted) {
        overlay.classList.remove('active');
    }
};