/**
 * Transição de Barras Escalonadas - Empresa
 * Cria um efeito de preenchimento por tiras verticais.
 */

(function() {
    // 1. Configuração do CSS
    const estilo = document.createElement('style');
    estilo.innerHTML = `
        .transicao-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            display: flex;
            z-index: 10000;
            pointer-events: none;
        }

        .barra {
            flex: 1;
            height: 100%;
            background-color: #6C63FF;
            transform: scaleY(0);
            transition: transform 0.6s cubic-bezier(0.8, 0, 0.2, 1);
        }

        /* Origem da animação: Cima para Baixo ao entrar */
        .barra.sobe { transform-origin: top; }
        
        /* Origem da animação: Baixo para Cima ao sair */
        .barra.desce { transform-origin: bottom; }

        .barra.ativa {
            transform: scaleY(1);
        }
    `;
    document.head.appendChild(estilo);

    // 2. Cria as barras (5 barras para um visual equilibrado)
    const container = document.createElement('div');
    container.classList.add('transicao-container');
    
    const numBarras = 5;
    const barrasArray = [];

    for (let i = 0; i < numBarras; i++) {
        const barra = document.createElement('div');
        barra.classList.add('barra');
        // Adiciona um pequeno atraso (delay) para cada barra
        barra.style.transitionDelay = (i * 0.1) + 's';
        container.appendChild(barra);
        barrasArray.push(barra);
    }
    
    document.body.appendChild(container);

    // 3. Animação de ENTRADA (Revelando a página)
    window.addEventListener('load', () => {
        // Define que elas vão "encolher" para cima
        barrasArray.forEach(b => {
            b.classList.add('ativa', 'sobe');
        });

        // Pequeno timeout para disparar a transição de saída
        setTimeout(() => {
            barrasArray.forEach(b => b.classList.remove('ativa'));
        }, 50);
    });

    // 4. Animação de SAÍDA (Ao clicar em links)
    document.addEventListener('click', (e) => {
        const link = e.target.closest('a');

        if (link && link.href && !link.target && !link.href.includes('#')) {
            if (link.hostname !== window.location.hostname) return;

            e.preventDefault();
            const url = link.href;

            // Define que elas vão "subir" preenchendo a tela
            barrasArray.forEach(b => {
                b.classList.remove('sobe');
                b.classList.add('desce', 'ativa');
            });

            // Navega após a última barra terminar (delay da última barra + tempo da transição)
            setTimeout(() => {
                window.location.href = url;
            }, 1000); 
        }
    });
})();