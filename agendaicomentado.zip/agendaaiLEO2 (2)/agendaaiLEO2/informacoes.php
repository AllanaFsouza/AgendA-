<?php
session_start();

// Exemplo: pegar dados da sessão
$nome_usuario = $_SESSION['empresa_nome'] ?? 'Admin';
$email_usuario = $_SESSION['empresa_email'] ?? 'admin@email.com';

// 🔗 Conexão centralizada
require_once "conexao.php"; // aqui já conecta usando $conn
?>

<?php
// obtem os dados do BD
$empresa_id = $_SESSION['empresa_id'] ?? 0;

$localizacao = "";
$unidade = "";
$abertura = "";
$fechamento = "";
$nome_loja = "";

if ($empresa_id) {
    $sql = "SELECT * FROM informacoes_loja WHERE empresa_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $empresa_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $dados = $result->fetch_assoc();

        $localizacao = $dados['localizacao'];
        $unidade = $dados['unidade'];
        $abertura = $dados['horario_abertura'];
        $fechamento = $dados['horario_fechamento'];
        $nome_loja = $dados['nome_loja'] ?? '';
    }
}

$dias_suspensos = [];

if ($empresa_id) {
    $sqlDias = "SELECT * FROM dias_suspensos WHERE empresa_id = ? ORDER BY data ASC";
    $stmtDias = $conn->prepare($sqlDias);
    $stmtDias->bind_param("i", $empresa_id);
    $stmtDias->execute();
    $resultDias = $stmtDias->get_result();

    while ($row = $resultDias->fetch_assoc()) {
        $dias_suspensos[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sua Empresa | Informações</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background: #e5e5e5;
            overflow: hidden;
        }

        /* --- SIDEBAR PADRONIZADA --- */
        .sidebar {
            width: 280px;
            background: #1b1f4b;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
        }

        .logo {
            padding: 25px 20px;
            font-weight: 800;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .menu {
            flex: 1;
            padding: 10px 0;
        }

        .menu-title {
            padding: 15px 20px 5px 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.5;
            font-weight: 600;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
        }

        .menu a i {
            width: 20px;
            text-align: center;
            font-size: 16px;
        }

        .menu a:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .menu a.active {
            background: #4e63ff;
            font-weight: 600;
        }

        /* RODAPÉ DO USUÁRIO NA SIDEBAR */
        .sidebar-footer {
            padding: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .user-info-box {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info-box i {
            background: white;
            color: #1b1f4b;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .user-details {
            display: flex;
            flex-direction: column;
        }

        .user-details strong {
            font-size: 13px;
            display: block;
        }

        .user-details span {
            font-size: 11px;
            opacity: 0.7;
        }

        .logout-btn {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            opacity: 0.8;
            transition: 0.2s;
            cursor: pointer;
        }

        .logout-btn:hover {
            opacity: 1;
        }

        /* --- CONTEÚDO --- */
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .page-header {
            background: white;
            padding: 20px 30px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-text h1 {
            font-size: 20px;
            color: #333;
        }

        .header-text p {
            font-size: 12px;
            color: #777;
        }

        .notification-icon {
            width: 35px;
            height: 35px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #555;
            cursor: pointer;
        }

        .page-body {
            padding: 30px;
        }

        /* Cards de Resumo */
        .summary-cards {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }

        .card-small {
            background: white;
            padding: 20px;
            border-radius: 15px;
            border: 1px solid #eee;
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
        }

        .card-small i {
            font-size: 24px;
            color: #4e63ff;
        }

        .card-small h3 {
            font-size: 20px;
            color: #1b1f4b;
        }

        .card-small p {
            font-size: 12px;
            color: #888;
        }

        /* Container de Dados */
        .data-container {
            background: #f9f9f9;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 30px;
        }

        .section-header i {
            font-size: 22px;
            color: #4e63ff;
        }

        .section-header h2 {
            font-size: 18px;
            color: #1b1f4b;
        }

        .section-header p {
            font-size: 12px;
            color: #888;
        }

        /* Grid Formulário */
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }

        .input-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .input-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: #555;
            font-weight: 600;
        }

        .input-label i {
            color: #4e63ff;
            font-size: 14px;
        }

        .form-grid input {
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background: white;
            outline: none;
            transition: 0.3s;
        }

        .form-grid input:focus {
            border-color: #4e63ff;
            box-shadow: 0 0 0 3px rgba(78, 99, 255, 0.1);
        }

        /* MODAL LOGOUT */
        .modal-logout {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal-logout-box {
            background: white;
            padding: 30px;
            border-radius: 15px;
            width: 320px;
            text-align: center;
        }

        .modal-logout-box h2 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .modal-logout-box p {
            font-size: 14px;
            color: #666;
            margin-bottom: 20px;
        }

        .modal-logout-buttons {
            display: flex;
            gap: 10px;
        }

        .modal-logout-buttons button {
            flex: 1;
            padding: 10px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 600;
        }

        .cancel {
            background: #eee;
        }

        .confirm {
            background: #ff4d4d;
            color: white;
        }

        /* Remova o border-bottom desta classe se você o tiver adicionado */
        .menu-title {
            padding: 15px 20px 5px 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.5;
            font-weight: 600;
            border-bottom: none;
            /* Garante que não tenha borda aqui */
        }

        /* Adicione esta regra para a linha abaixo do logo */
        .logo {
            padding: 25px 20px;
            font-weight: 800;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            /* A linha fina abaixo do logo */
        }

        :root {
            --cor-tema: #6C63FF;
        }

        body {
            display: flex;
            height: 100vh;
            background: #e5e5e5;
            overflow: hidden;
            /* <- isso impede rolagem e pode interferir */
        }

        /* SELECT PADRÃO BONITO */
        .form-grid select {
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background: white;
            outline: none;
            transition: 0.3s;
            font-size: 14px;
            cursor: pointer;

            /* Remove estilo padrão feio do navegador */
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;

            /* Seta personalizada */
            background-image: url("data:image/svg+xml;utf8,<svg fill='%23666' height='20' viewBox='0 0 20 20' width='20' xmlns='http://www.w3.org/2000/svg'><path d='M5 7l5 5 5-5z'/></svg>");
            background-repeat: no-repeat;
            background-position: right 10px center;
            background-size: 16px;
        }

        /* HOVER */
        .form-grid select:hover {
            border-color: #4e63ff;
        }

        /* FOCO */
        .form-grid select:focus {
            border-color: #4e63ff;
            box-shadow: 0 0 0 3px rgba(78, 99, 255, 0.1);
        }

        /* Linha dos horários */
        .horarios-row {
            display: flex;
            gap: 10px;
        }

        /* Inputs de horário com tamanho igual */
        .horarios-row input {
            flex: 1;
            height: 44px;
        }

        /* Select com mesma altura dos inputs */
        .form-grid select {
            height: 44px;
        }
    </style>
</head>

<body>
    <aside class="sidebar">
        <div>
            <div class="logo">
                <i class="fa-solid fa-scissors"></i> agendaAi
            </div>


            <nav class="menu">
                <div class="menu-title">Editar site</div>
                <a href="dashboardadmin.php"><i class="fa-solid fa-chart-line"></i> Dashboard Inicial</a>
                <a href="previsualizacao_cliente.php"><i class="fa-regular fa-eye"></i> Pré-visualização</a>
                <a href="#" class="active"><i class="fa-solid fa-circle-info"></i> Informações</a>
                <a href="editardadosEmpresa.php"><i class="fa-solid fa-id-card"></i> Dados da Empresa</a>
                <div class="menu-title">Gerenciar</div>
                <a href="servicos.php"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</a>
                <a href="equipe.php"><i class="fa-solid fa-users"></i> Equipe</a>
                <a href="agendamentos.php"><i class="fa-regular fa-calendar-check"></i> Agendamentos</a>
                <a href="clientes.php"><i class="fa-solid fa-user-group"></i> Clientes</a>

            </nav>
        </div>

        <div class="sidebar-footer">
            <div class="user-info-box">
                <i class="fa-solid fa-user"></i>
                <div class="user-details">
                    <strong><?php echo htmlspecialchars($nome_usuario); ?></strong>
                    <span><?php echo htmlspecialchars($email_usuario); ?></span>
                </div>
            </div>
            <a href="#" class="logout-btn" id="sidebarLogout">
                <i class="fa-solid fa-right-from-bracket"></i> Sair
            </a>
        </div>
    </aside>
    <main class="content">
        <header class="page-header">
            <div class="header-text">
                <h1>Informações da Loja</h1>
                <p>Configure os dados gerais do seu salão</p>
            </div>
            <div class="notification-icon"><i class="fa-solid fa-bell"></i></div>
        </header>

        <div class="page-body">

            <!-- 🔹 SUMMARY CARDS -->
            <div class="summary-cards">
                <div class="card-small">
                    <i class="fa-regular fa-star"></i>
                    <div>
                        <h3>5.0</h3>
                        <p>Avaliação Média</p>
                    </div>
                </div>
                <div class="card-small">
                    <i class="fa-regular fa-clock"></i>
                    <div>
                        <h3 id="display-horario">00h - 00h</h3>
                        <p>Horário de Funcionamento</p>
                    </div>
                </div>
            </div>

            <!-- 🔹 FORM PRINCIPAL DE INFORMAÇÕES DA LOJA -->
            <div class="data-container">
                <div class="section-header">
                    <i class="fa-solid fa-store"></i>
                    <div>
                        <h2>Dados da Loja</h2>
                        <p>Configure as informações exibidas ao cliente no site</p>
                    </div>
                </div>

                <form action="salvar_informacoes.php" method="POST" class="form-grid">
                    <!-- Nome -->
                    <div class="input-group">
                        <div class="input-label">
                            <i class="fa-solid fa-store"></i> Nome da Empresa
                        </div>
                        <input type="text" name="nome_loja" value="<?php echo htmlspecialchars($nome_loja); ?>"
                            placeholder="Ex: Barbearia do João">
                    </div>

                    <!-- Localização -->
                    <div class="input-group">
                        <div class="input-label">
                            <i class="fa-solid fa-location-dot"></i> Localização
                        </div>
                        <input type="text" name="localizacao" value="<?php echo htmlspecialchars($localizacao); ?>"
                            placeholder="Ex: Centro, Rua Direita, 123">
                    </div>

                    <!-- Unidade -->
                    <div class="input-group">
                        <div class="input-label">
                            <i class="fa-solid fa-building"></i> Unidade
                        </div>
                        <input type="text" name="unidade" value="<?php echo htmlspecialchars($unidade); ?>"
                            placeholder="Ex: Shopping, Loja 02">
                    </div>

                    <!-- Horários -->
                    <div class="input-group">
                        <div class="input-label">
                            <i class="fa-solid fa-clock"></i> Horário de Funcionamento
                        </div>
                        <div style="display:flex; gap:10px;">
                            <input type="time" id="horario-abertura" name="horario_abertura"
                                value="<?php echo $abertura ?: '09:00'; ?>">
                            <input type="time" id="horario-fechamento" name="horario_fechamento"
                                value="<?php echo $fechamento ?: '19:00'; ?>">
                        </div>
                    </div>

                    <!-- Intervalo -->
                    <div class="input-group">
                        <div class="input-label">
                            <i class="fa-solid fa-hourglass-half"></i> Intervalo dos atendimentos
                        </div>
                        <select name="intervalo">
                            <option value="30">30 minutos</option>
                            <option value="60">1 hora</option>
                            <option value="90">1 hora e meia</option>
                            <option value="120">2 horas</option>
                        </select>
                    </div>

                    <!-- Botão Salvar -->
                    <div style="grid-column: span 2; margin-top: 15px;">
                        <button type="submit"
                            style="padding: 12px 20px; border-radius: 10px; background: #4e63ff; color: white; border: none; cursor: pointer;">
                            Salvar
                        </button>
                    </div>
                </form>
            </div> <!-- Fim do FORM PRINCIPAL -->

            <!-- 🔹 NOVA DIV PARA SUSPENDER DIAS -->
            <div class="data-container" style="margin-top: 30px;">
                <h2>Suspender dia</h2>

                <!-- Form para suspender dia -->
                <form action="suspender_dia.php" method="POST"
                    style="display:flex; gap:10px; align-items:center; margin-bottom: 20px;">
                    <input type="date" name="data_suspensa" required
                        style="padding:10px; border-radius:8px; border:1px solid #ccc;">
                    <button type="submit"
                        style="padding:10px 15px; border:none; background:#ff4d4d; color:white; border-radius:8px; cursor:pointer;">
                        Suspender dia
                    </button>
                </form>

                <!-- Lista de dias suspensos -->
                <?php if (count($dias_suspensos) > 0): ?>
                    <div class="dias-suspensos-list" style="display:flex; flex-direction:column; gap:10px;">
                        <h2>Dias suspensos</h2>
                        <?php foreach ($dias_suspensos as $dia): ?>
                            <div
                                style="background:white; padding:10px 15px; border-radius:8px; display:flex; justify-content:space-between; align-items:center; border:1px solid #eee;">
                                <span><?php echo date('d/m/Y', strtotime($dia['data'])); ?></span>
                                <form action="remover_dia.php" method="POST" style="margin:0;">
                                    <input type="hidden" name="id" value="<?php echo $dia['id']; ?>">
                                    <button type="submit"
                                        style="background:#ff4d4d; border:none; color:white; padding:5px 10px; border-radius:6px; cursor:pointer;">
                                        Remover
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p style="color:#777;">Nenhum dia suspenso</p>
                <?php endif; ?>
            </div> <!-- Fim da DIV de dias suspensos -->

        </div> <!-- Fim page-body -->
    </main>


    <script>
        // exibição de dados 
        const displayHorario = document.getElementById('display-horario');
        const horarioAbertura = document.getElementById('horario-abertura');
        const horarioFechamento = document.getElementById('horario-fechamento');

        function atualizarHorario() {
            let abertura = horarioAbertura.value;
            let fechamento = horarioFechamento.value;

            if (!abertura) abertura = "--:--";
            if (!fechamento) fechamento = "--:--";

            // Formata para hh:mm -> hh'h' - hh'h'
            let a = abertura.replace(":", "h");
            let f = fechamento.replace(":", "h");
            displayHorario.textContent = `${a} - ${f}`;
        }

        // Atualiza ao carregar página
        atualizarHorario();

        // Atualiza quando usuário muda os horários
        horarioAbertura.addEventListener('input', atualizarHorario);
        horarioFechamento.addEventListener('input', atualizarHorario);
    </script>

    <script src="transicao.js"></script>
    <script src="logout.js"></script>
</body>

</html>