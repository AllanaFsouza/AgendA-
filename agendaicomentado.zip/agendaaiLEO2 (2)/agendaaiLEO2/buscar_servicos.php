<!-- Trabalha com o código agendamentos na página do cliente, busca os serviços -->

<?php
require_once "conexao.php"; // conexão centralizada

$categoria = $_GET['categoria'] ?? '';

$sql = "SELECT * FROM servicos WHERE categoria = ? AND ativo = 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $categoria);
$stmt->execute();

$result = $stmt->get_result();

$servicos = [];

while($row = $result->fetch_assoc()){
    $servicos[] = $row;
}

echo json_encode($servicos);
?>
