<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // conexão centralizada

/* 🔒 GARANTE QUE ESTÁ LOGADO */
if (!isset($_SESSION['empresa_id'])) {
    die("Acesso negado");
}

$empresa_id = $_SESSION['empresa_id'];

/* 📥 PEGAR DADOS DO FORM */
$localizacao = $_POST['localizacao'] ?? '';
$unidade = $_POST['unidade'] ?? '';
$abertura = $_POST['horario_abertura'] ?? '';
$fechamento = $_POST['horario_fechamento'] ?? '';
$nome_loja = $_POST['nome_loja'] ?? '';
$intervalo = $_POST['intervalo'] ?? 30; // padrão 30 min

/* 🧠 FUNÇÃO PARA GERAR HORÁRIOS */
function gerarHorarios($inicio, $fim, $intervalo) {
    $horarios = [];
    $start = strtotime($inicio);
    $end = strtotime($fim);

    while ($start < $end) {
        $horarios[] = date("H:i", $start);
        $start = strtotime("+$intervalo minutes", $start);
    }

    return $horarios;
}

/* ⏱ GERAR HORÁRIOS */
$horarios = gerarHorarios($abertura, $fechamento, $intervalo);
$horarios_json = json_encode($horarios);

/* 🔍 VERIFICA SE JÁ EXISTE REGISTRO */
$sql_check = "SELECT id FROM informacoes_loja WHERE empresa_id = ?";
$stmt = $conn->prepare($sql_check);
$stmt->bind_param("i", $empresa_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {

    /* 🔄 UPDATE */
    $sql = "UPDATE informacoes_loja 
            SET nome_loja = ?, 
                localizacao = ?, 
                unidade = ?, 
                horario_abertura = ?, 
                horario_fechamento = ?, 
                horarios_disponiveis = ?
            WHERE empresa_id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ssssssi",
        $nome_loja,
        $localizacao,
        $unidade,
        $abertura,
        $fechamento,
        $horarios_json,
        $empresa_id
    );

} else {

    /* ➕ INSERT */
    $sql = "INSERT INTO informacoes_loja 
            (empresa_id, nome_loja, localizacao, unidade, horario_abertura, horario_fechamento, horarios_disponiveis)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "issssss",
        $empresa_id,
        $nome_loja,
        $localizacao,
        $unidade,
        $abertura,
        $fechamento,
        $horarios_json
    );
}

/* 🚀 EXECUTA */
if ($stmt->execute()) {
    $stmt->close(); // fechar statement
    header("Location: informacoes.php?sucesso=1");
    exit;
} else {
    echo "Erro ao salvar: " . $stmt->error;
    $stmt->close();
}

// ✅ $conn não é fechado, vem do conexao.php
?>
