<!-- inicialização da sessão, busca dados como nome e email da empresa --> 

<?php
session_start();
$nome_usuario = $_SESSION['empresa_nome'] ?? 'Admin';
$email_usuario = $_SESSION['empresa_email'] ?? 'admin@gmail.com';

require_once "conexao.php"; // <-- conexão com o banco 

date_default_timezone_set('America/Sao_Paulo');
$hoje = date('Y-m-d'); // padronização de formato de horário 

// BUSCAR AGENDAMENTOS DE HOJE
$sql = "SELECT a.*, u.nome 
        FROM agendamentos_cliente a
        JOIN cadastro_usuario u ON a.id_usuario = u.id
        WHERE a.data_agendamento = ?
        AND a.status = 'ativo'
        ORDER BY a.horario ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $hoje);
$stmt->execute();
$result = $stmt->get_result();

// TOTAL DE CLIENTES ATIVOS
$sqlClientes = "SELECT COUNT(DISTINCT id_usuario) as total 
                FROM agendamentos_cliente 
                WHERE status = 'ativo'
                AND data_agendamento = ?";

$stmtClientes = $conn->prepare($sqlClientes);
$stmtClientes->bind_param("s", $hoje);
$stmtClientes->execute();

$resultClientes = $stmtClientes->get_result();
$rowClientes = $resultClientes->fetch_assoc();

$totalClientes = $rowClientes['total'] ?? 0;
// TOTAL DE HOJE
$totalHoje = $result->num_rows;

// FATURAMENTO DE HOJE
$sqlFaturamento = "
    SELECT SUM(s.preco) as total
    FROM agendamentos_cliente a
    JOIN servicos s ON s.nome = a.servicos
    WHERE a.data_agendamento = ?
    AND a.status = 'concluido'
";

$stmtFat = $conn->prepare($sqlFaturamento);
$stmtFat->bind_param("s", $hoje);
$stmtFat->execute();
$resultFaturamento = $stmtFat->get_result();
$rowFaturamento = $resultFaturamento->fetch_assoc();
$totalFaturamento = $rowFaturamento['total'] ?? 0;

// Fechar statements (opcional)
$stmt->close();
$stmtFat->close();
?>

<!-- html -->
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Sua | Painel ADM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- ESTILOS BASE --- */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background: #f4f6f9;
            overflow: hidden;
        }

        /* --- SIDEBAR PADRONIZADA --- */
        .sidebar {
            width: 280px;
            background: #1b1f4b;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
        }

        .logo {
            padding: 25px 20px;
            font-weight: 800;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .menu {
            flex: 1;
            padding: 10px 0;
        }

        .menu-title {
            padding: 15px 20px 5px 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.5;
            font-weight: 600;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
        }

        .menu a i {
            width: 20px;
            text-align: center;
            font-size: 16px;
        }

        .menu a:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .menu a.active {
            background: #4e63ff;
            font-weight: 600;
        }

        .sidebar-footer {
            padding: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .user-info-box {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info-box i {
            background: white;
            color: #1b1f4b;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .user-details {
            display: flex;
            flex-direction: column;
        }

        .user-details strong {
            font-size: 13px;
            display: block;
        }

        .user-details span {
            font-size: 11px;
            opacity: 0.7;
        }

        .logout-btn {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            opacity: 0.8;
            transition: 0.2s;
        }

        .logout-btn:hover {
            opacity: 1;
        }

        /* --- CONTENT --- */
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        header {
            background-color: #6C63FF;
            color: #fff;
            padding: 20px 40px;
            flex-shrink: 0;
        }

        .logo-header {
            font-size: 18px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .hero {
            background-color: #6C63FF;
            color: #fff;
            padding: 20px 40px 80px 40px;
        }

        .hero h1 {
            font-size: 32px;
            font-weight: 800;
        }

        .container {
            padding: 0 40px 40px 40px;
        }

        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-top: -50px;
        }

        .card {
            background: #fff;
            padding: 25px 20px;
            text-align: center;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .05);
        }

        .recent-appointments {
            background: #fff;
            border-radius: 18px;
            padding: 25px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .05);
            margin-top: 30px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .btn-view-all {
            font-size: 13px;
            color: #4e63ff;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            font-size: 11px;
            text-transform: uppercase;
            color: #777;
            padding-bottom: 15px;
            border-bottom: 1px solid #f0f0f0;
        }

        td {
            padding: 15px 0;
            font-size: 14px;
            border-bottom: 1px solid #f9f9f9;
        }

        .status {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
        }

        .status.pending {
            background: #fff4e5;
            color: #ff9800;
        }

        .status.confirmed {
            background: #e7f9ed;
            color: #2ecc71;
        }

        .action-btn {
            border: none;
            background: #f4f6f9;
            width: 32px;
            height: 32px;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.2s;
        }

        .action-btn.confirm:hover {
            background: #e7f9ed;
            color: #2ecc71;
        }

        .action-btn.delete:hover {
            background: #ffebeb;
            color: #ff4757;
        }
    </style>
</head>

<body>
    <aside class="sidebar">
        <div>
            <div class="logo">
                <i class="fa-solid fa-scissors"></i> agendaAi
            </div>

            <nav class="menu">
                <div class="menu-title">Editar site</div>
                <a href="#" class="active"><i class="fa-solid fa-chart-line"></i> Dashboard Inicial</a>
                <a href="previsualizacao_cliente.php"><i class="fa-regular fa-eye"></i> Pré-visualização</a>
                <a href="informacoes.php"><i class="fa-solid fa-circle-info"></i> Informações</a>
                <a href="editardadosEmpresa.php"><i class="fa-solid fa-id-card"></i> Dados da Empresa</a>

                <div class="menu-title">Gerenciar</div>
                <a href="servicos.php"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</a>
                <a href="equipe.php"><i class="fa-solid fa-users"></i> Equipe</a>
                <a href="agendamentos.php"><i class="fa-solid fa-calendar"></i> Agendamento</a>
                <a href="clientes.php"><i class="fa-solid fa-user"></i> Clientes</a>
            </nav>
        </div>

        <div class="sidebar-footer">
            <div class="user-info-box">
                <i class="fa-solid fa-user"></i>
                <div class="user-details">
                    <strong><?php echo htmlspecialchars($nome_usuario); ?></strong>
                    <span><?php echo htmlspecialchars($email_usuario); ?></span>
                </div>


            </div>
            <a href="#" class="logout-btn" id="sidebarLogout">
                <i class="fa-solid fa-right-from-bracket"></i> Sair
            </a>
        </div>
    </aside>

    <main class="content">
        <header>

        </header>

        <section class="hero">
            <p>Olá, <?php echo htmlspecialchars($nome_usuario); ?> 👋</p>
            <h1>Painel Administrativo</h1>
        </section>

        <section class="container">

            <!-- CARDS -->
            <div class="cards">
                <div class="card">
                    <i class="fa-solid fa-calendar-day"></i>
                    <h3 id="count-hoje"><?php echo isset($totalHoje) ? $totalHoje : 0; ?></h3>
                    <p>Agendamentos Hoje</p>
                </div>

                <div class="card">
                    <i class="fa-solid fa-users"></i>
                    <h3><?php echo $totalClientes; ?></h3>

                    <p>Clientes</p>
                </div>

                <div class="card">
                    <i class="fa-regular fa-star"></i>
                    <h3>5.0</h3>
                    <p>Avaliação</p>
                </div>

                <div class="card">
                    <i class="fa-solid fa-money-bill-wave"></i>
                    <h3 id="faturamento">R$ <?php echo number_format($totalFaturamento, 2, ',', '.'); ?></h3>

                    <p>Faturamento</p>
                </div>
            </div>

            <!-- TABELA -->
            <div class="recent-appointments">
                <div class="section-header">
                    <h2>Agendamentos de Hoje</h2>
                    <span class="btn-view-all" onclick="window.location.href='agendamentos.php'">
                        Ver todos <i class="fa-solid fa-arrow-right"></i>
                    </span>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Cliente</th>
                            <th>Serviço</th>
                            <th>Horário</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>

                    <tbody id="lista-corpo">

                    <!-- puxa os dados do banco para exibir na tabela -->

                        <?php if (!empty($result) && $result->num_rows > 0): ?>

                            <?php while ($row = $result->fetch_assoc()): ?>

                                <tr>
                                    <td><strong><?php echo htmlspecialchars($row['nome']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($row['servicos']); ?></td>
                                    <td><?php echo date("H:i", strtotime($row['horario'])); ?></td>

                                    <td>
                                    <td>
                                        <?php if ($row['status'] == 'ativo'): ?>
                                            <span class="status pending">Pendente</span>

                                        <?php elseif ($row['status'] == 'concluido'): ?>
                                            <span class="status confirmed">Concluído</span>

                                        <?php else: ?>
                                            <span class="status pending">Cancelado</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?php if ($row['status'] == 'ativo'): ?>
                                            <button class="action-btn confirm" onclick="confirmar(this, <?php echo $row['id']; ?>)">
                                                <i class="fa-solid fa-check"></i>
                                            </button>
                                        <?php endif; ?>


                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="5" style="text-align:center; color:#777;">
                                    Nenhum agendamento hoje
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>
                </table>
            </div>

        </section>
    </main>

    <!-- MODAL de excluir -->
    <div id="modalExcluir"
        style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); justify-content:center; align-items:center;">
        <div style="background:white; padding:20px; border-radius:10px;">
            <p>Deseja excluir?</p>
            <button onclick="fecharModal()">Cancelar</button>
            <button id="btnConfirmarExclusao">Excluir</button>
        </div>
    </div>

    <script>
        
        function confirmar(btn, id) {
            fetch("concluir_agendamento.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "id=" + id
            })
                .then(res => res.text())
                .then(res => {
                    if (res === "ok") {
                        const row = btn.closest("tr");
                        const status = row.querySelector(".status");

                        status.textContent = "Concluído";
                        status.className = "status confirmed";

                        btn.style.display = "none";
                    }
                });
        }


        // EXCLUIR
        let linhaParaExcluir = null;

        function excluir(btn) {
            linhaParaExcluir = btn.closest("tr");
            document.getElementById('modalExcluir').style.display = 'flex';
        }

        function fecharModal() {
            document.getElementById('modalExcluir').style.display = 'none';
        }

        // CONFIRMAR EXCLUSÃO
        document.getElementById('btnConfirmarExclusao').onclick = function () {
            if (linhaParaExcluir) {
                linhaParaExcluir.remove();
                linhaParaExcluir = null;
                atualizarContador();
                fecharModal();
            }
        };



    </script>


    <script src="logout.js"></script>
    <script src="transicao.js"></script>

</body>

</html>