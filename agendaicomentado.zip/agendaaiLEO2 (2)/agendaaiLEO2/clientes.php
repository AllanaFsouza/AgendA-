<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

// VERIFICA SE ESTÁ LOGADO
if (!isset($_SESSION['empresa_id'])) {
    header("Location: login_empresa.html");
    exit;
}

$empresa_id = $_SESSION['empresa_id'];

// BUSCAR DADOS DA EMPRESA
$sqlEmpresa = "SELECT nome_empresa, responsavel, email FROM cadastro_empresa WHERE id_empresa = ?";
$stmt = $conn->prepare($sqlEmpresa);
$stmt->bind_param("i", $empresa_id);
$stmt->execute();
$resultEmpresa = $stmt->get_result();
$empresa = $resultEmpresa->fetch_assoc();
$nome_empresa = $empresa['nome_empresa'] ?? 'Minha Empresa';
$nome_usuario = $empresa['responsavel'] ?? 'Usuário';
$email_usuario = $empresa['email'] ?? 'email@empresa.com';

// TOTAL DE CLIENTES
$sqlTotal = "SELECT COUNT(*) as total FROM cadastro_usuario";
$resultTotal = $conn->query($sqlTotal);
$rowTotal = $resultTotal->fetch_assoc();
$totalClientes = $rowTotal['total'];

// BUSCAR CLIENTES + TOTAL DE AGENDAMENTOS
$sql = "
SELECT 
    u.id,
    u.nome,
    COUNT(a.id) as total_agendamentos
FROM cadastro_usuario u
LEFT JOIN agendamentos_cliente a 
    ON u.id = a.id_usuario
GROUP BY u.id
ORDER BY u.id DESC
";

$result = $conn->query($sql);
$maiorNivel = 0;

// percorre uma cópia do resultado
$temp = $conn->query($sql);

while($c = $temp->fetch_assoc()){
    $visitas = $c['total_agendamentos'] ?? 0;
    $nivel = min(5, floor($visitas / 5) + 1);

    if ($nivel > $maiorNivel) {
        $maiorNivel = $nivel;
    }
}
$totalVisitas = 0;
$totalUsuarios = 0;

// percorre novamente
$temp2 = $conn->query($sql);

while($c = $temp2->fetch_assoc()){
    $visitas = $c['total_agendamentos'] ?? 0;

    $totalVisitas += $visitas;
    $totalUsuarios++;
}

// evita divisão por zero
$mediaVisitas = ($totalUsuarios > 0) ? round($totalVisitas / $totalUsuarios, 1) : 0;
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sua Empresa | Clientes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            display: flex;
            height: 100vh;
            background: #e5e5e5;
            overflow: hidden;
        }

        /* --- SIDEBAR PADRONIZADA --- */
        .sidebar {
            width: 280px;
            background: #1b1f4b;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
        }

        .logo {
            padding: 25px 20px;
            font-weight: 800;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .menu {
            flex: 1;
            padding: 10px 0;
        }

        .menu-title {
            padding: 15px 20px 5px 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.5;
            font-weight: 600;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
        }

        .menu a i {
            width: 20px;
            text-align: center;
            font-size: 16px;
        }

        .menu a:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .menu a.active {
            background: #4e63ff;
            font-weight: 600;
        }

        /* RODAPÉ DO USUÁRIO NA SIDEBAR */
        .sidebar-footer {
            padding: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .user-info-box {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info-box i {
            background: white;
            color: #1b1f4b;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .user-details {
            display: flex;
            flex-direction: column;
        }

        .user-details strong {
            font-size: 13px;
            display: block;
        }

        .user-details span {
            font-size: 11px;
            opacity: 0.7;
        }

        .logout-btn {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            opacity: 0.8;
            transition: 0.2s;
        }

        .logout-btn:hover {
            opacity: 1;
        }

        /* --- CONTEÚDO --- */
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .page-header {
            background: white;
            padding: 20px 30px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-text h1 { font-size: 20px; color: #333; }
        .header-text p { font-size: 12px; color: #777; }

        .notification-icon {
            width: 35px;
            height: 35px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #555;
            cursor: pointer;
        }

        .page-body {
            padding: 30px;
        }

        /* DASHBOARD CARDS */
        .cards {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            flex: 1;
            background: white;
            padding: 20px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.03);
            border: 1px solid #eee;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .icon-users { background: #eef1ff; color: #4e63ff; }
        .icon-trophy { background: #fff8e5; color: #ffb800; }
        .icon-chart { background: #e9f7ef; color: #27ae60; }

        .stat-info strong { font-size: 22px; color: #1b1f4b; display: block; }
        .stat-info span { font-size: 12px; color: #888; }

        /* LISTA DE CLIENTES */
        .clientes-box {
            background: #f9f9f9;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.05);
        }

        .clientes-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 5px;
        }

        .clientes-header i { color: #4e63ff; font-size: 18px; }
        .clientes-header h2 { font-size: 18px; color: #1b1f4b; }
        .clientes-sub { font-size: 12px; color: #888; margin-left: 28px; margin-bottom: 25px; }

        .cliente {
            background: white;
            border-radius: 12px;
            padding: 16px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 12px;
            border: 1px solid #eee;
        }

        .cliente-left { display: flex; align-items: center; gap: 15px; }
        .avatar { width: 40px; height: 40px; background: #eee; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #aaa; }
        
        .cliente-info strong { font-size: 15px; color: #333; display: block; }
        .cliente-info span { font-size: 12px; color: #888; }

        .nivel-container {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 6px;
        }

        .nivel-container span { font-size: 11px; font-weight: 700; color: #4e63ff; text-transform: uppercase; }

        .barra-progresso {
            width: 150px;
            height: 6px;
            background: #eee;
            border-radius: 10px;
            overflow: hidden;
        }

        .progresso {
            height: 100%;
            background: #4e63ff;
            border-radius: 10px;
        }
        /* Remova o border-bottom desta classe se você o tiver adicionado */
.menu-title {
    padding: 15px 20px 5px 20px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    opacity: 0.5;
    font-weight: 600;
    border-bottom: none; /* Garante que não tenha borda aqui */
}

/* Adicione esta regra para a linha abaixo do logo */
.logo {
    padding: 25px 20px;
    font-weight: 800;
    font-size: 18px;
    display: flex;
    align-items: center;
    gap: 10px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.08); /* A linha fina abaixo do logo */
}
:root {
  --cor-tema: #6C63FF;
}
body {
  display: flex;
  height: 100vh;
  background: #e5e5e5;
  overflow: hidden; /* <- isso impede rolagem e pode interferir */
}

    </style>
</head>
<body>

       <aside class="sidebar">
        <div>
             <div class="logo">
    <i class="fa-solid fa-scissors"></i> agendaAi
</div>
            <nav class="menu">
                <div class="menu-title">Editar site</div>
                <a href="dashboardadmin.php"><i class="fa-solid fa-chart-line"></i> Dashboard Inicial</a>
                <a href="previsualizacao_cliente.php"><i class="fa-regular fa-eye"></i> Pré-visualização</a>
                <a href="informacoes.php"><i class="fa-solid fa-circle-info"></i> Informações</a>
<a href="editardadosEmpresa.php"><i class="fa-solid fa-id-card"></i> Dados da Empresa</a>
                <div class="menu-title">Gerenciar</div>
                <a href="servicos.php"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</a>
                <a href="equipe.php" ><i class="fa-solid fa-users"></i> Equipe</a>
                <a href="agendamentos.php"><i class="fa-regular fa-calendar-check"></i> Agendamentos</a>
                <a href="clientes.php"class="active"><i class="fa-solid fa-user-group"></i> Clientes</a>
              
            </nav>
        </div>

        <div class="sidebar-footer">
            <div class="user-info-box">
                <i class="fa-solid fa-user"></i>
<div class="user-details">
    <strong><?php echo htmlspecialchars($nome_usuario); ?></strong>
    <span><?php echo htmlspecialchars($email_usuario); ?></span>
</div>
            </div>
            <a href="#" class="logout-btn" id="sidebarLogout">
                <i class="fa-solid fa-right-from-bracket"></i> Sair
            </a>
        </div>
    </aside>
 <!-- ✅ FECHADO CORRETAMENTE -->

    <main class="content"> <!-- ✅ CONTEÚDO FORA DA SIDEBAR -->

        <div class="page-body">
            
            <div class="cards">
                <div class="stat-card">
                    <div class="stat-icon icon-users">
                        <i class="fa-solid fa-user"></i>
                    </div>
                    <div class="stat-info">
                        <strong><?php echo $totalClientes; ?></strong>
                        <span>Cadastrados</span>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon icon-trophy">
                        <i class="fa-solid fa-trophy"></i>
                    </div>
                    <div class="stat-info">
                       <strong><?php echo $maiorNivel; ?></strong>
                        <span>Maior nível</span>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon icon-chart">
                        <i class="fa-solid fa-arrow-up"></i>
                    </div>
                    <div class="stat-info">
                       <strong><?php echo $mediaVisitas; ?></strong>
<span>Média visitas</span>
                    </div>
                </div>
            </div>

            <div class="clientes-box">
                <div class="clientes-header">
                    <i class="fa-solid fa-user-group"></i>
                    <h2>Clientes Cadastrados</h2>
                </div>

                <div class="clientes-sub">
                    Acompanhe a fidelidade e evolução dos seus clientes
                </div>

                <?php if ($result->num_rows > 0): ?>

                    <?php while($cliente = $result->fetch_assoc()): 

                        $visitas = $cliente['total_agendamentos'] ?? 0;
                        $nivel = min(5, floor($visitas / 5) + 1);
                        $progresso = min(100, ($visitas % 5) * 20);
                    ?>

                        <div class="cliente">
                            <div class="cliente-left">
                                <div class="avatar">
                                    <i class="fa-solid fa-user"></i>
                                </div>

                                <div class="cliente-info">
                                    <strong><?php echo htmlspecialchars($cliente['nome']); ?></strong>
                                    <span><?php echo $visitas; ?> visitas</span>
                                </div>
                            </div>

                            <div class="nivel-container">
                                <span>Nível <?php echo $nivel; ?></span>
                                <div class="barra-progresso">
                                    <div class="progresso" style="width:<?php echo $progresso; ?>%"></div>
                                </div>
                            </div>
                        </div>

                    <?php endwhile; ?>

                <?php else: ?>
                    <p>Nenhum cliente cadastrado.</p>
                <?php endif; ?>

            </div>
        </div>

    </main>

    <script src="logout.js"></script>
    <script src="transicao.js"></script>

</body>
</html>