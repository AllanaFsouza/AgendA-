<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // conexão centralizada

// 🔥 ID da empresa logada
$empresa_id = $_SESSION['empresa_id'] ?? 0;

if($empresa_id == 0){
    echo "erro_empresa";
    exit;
}

// RECEBER DADOS DO FORM
$nome = $_POST['nome'] ?? '';
$preco = $_POST['preco'] ?? 0;
$duracao = $_POST['duracao'] ?? '';
$categoria = $_POST['categoria'] ?? '';

if(!$nome || !$duracao || !$categoria){
    echo "dados_invalidos";
    exit;
}

$stmt = $conn->prepare("
    INSERT INTO servicos (empresa_id, nome, preco, duracao, categoria) 
    VALUES (?, ?, ?, ?, ?)
");

$stmt->bind_param("isdss", $empresa_id, $nome, $preco, $duracao, $categoria);

if ($stmt->execute()) {
    echo "ok";
} else {
    echo "erro";
}

$stmt->close(); // fechar statement

// ✅ $conn não é fechado, vem do conexao.php
?>
