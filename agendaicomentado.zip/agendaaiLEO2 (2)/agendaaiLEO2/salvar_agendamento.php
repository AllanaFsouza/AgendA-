<?php
session_start();
header('Content-Type: application/json');

ini_set('display_errors', 1);
error_reporting(E_ALL);

include 'conexao.php'; // já usa a conexão atualizada do InfinityFree

// ✅ VERIFICA SESSÃO CORRETA
if (!isset($_SESSION['id'])) {
    echo json_encode([
        "status" => "erro",
        "msg" => "Usuário não logado"
    ]);
    exit;
}

$id_usuario = $_SESSION['id'];
// ✅ VALIDAÇÃO DOS DADOS
if (
    empty($_POST['categoria']) ||
    empty($_POST['servicos']) ||
    empty($_POST['data']) ||
    empty($_POST['horario'])
) {
    echo json_encode([
        "status" => "erro",
        "msg" => "Dados incompletos"
    ]);
    exit;
}

$categoria = $_POST['categoria'];
$servicos = $_POST['servicos'];
$data = $_POST['data'];
$horario = $_POST['horario'];

// ✅ GARANTE FORMATO TIME (HH:MM:SS)
$horario = $horario . ":00";

// ✅ CONVERTE DATA
$dataObj = DateTime::createFromFormat('d/m/Y', $data);

if (!$dataObj) {
    echo json_encode([
        "status" => "erro",
        "msg" => "Data inválida",
        "data_recebida" => $data
    ]);
    exit;
}

$dataFormatada = $dataObj->format('Y-m-d');

// ✅ VERIFICA SE JÁ EXISTE AGENDAMENTO
$sqlCheck = "SELECT id FROM agendamentos_cliente 
             WHERE data_agendamento = ? AND horario = ?";

$stmt = $conn->prepare($sqlCheck);

if (!$stmt) {
    echo json_encode([
        "status" => "erro",
        "msg" => "Erro no prepare (check)",
        "erro_sql" => $conn->error
    ]);
    exit;
}

$stmt->bind_param("ss", $dataFormatada, $horario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(["status" => "ocupado"]);
    exit;
}

// ✅ INSERT
$sql = "INSERT INTO agendamentos_cliente 
        (id_usuario, categoria, servicos, data_agendamento, horario) 
        VALUES (?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "status" => "erro",
        "msg" => "Erro no prepare (insert)",
        "erro_sql" => $conn->error
    ]);
    exit;
}

$stmt->bind_param("issss", $id_usuario, $categoria, $servicos, $dataFormatada, $horario);

// ✅ EXECUTA E MOSTRA ERRO REAL SE FALHAR
if ($stmt->execute()) {
    echo json_encode(["status" => "sucesso"]);
} else {
    echo json_encode([
        "status" => "erro",
        "erro_sql" => $stmt->error
    ]);
}
?>
