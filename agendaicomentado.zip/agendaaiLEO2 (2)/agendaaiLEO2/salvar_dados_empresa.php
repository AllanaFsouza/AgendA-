<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

// ID DA EMPRESA (ideal: usar sessão depois)
$id_empresa = $_SESSION['empresa_id'] ?? 15;

// RECEBER DADOS (somente os que podem editar)
$nome_empresa = trim($_POST['razao_social'] ?? '');
$telefone = trim($_POST['telefone'] ?? '');
$responsavel = trim($_POST['responsavel'] ?? '');

// VALIDAÇÃO
if (empty($nome_empresa) || empty($responsavel)) {
    http_response_code(400);
    exit("Dados obrigatórios faltando");
}

// UPDATE (SEM email e senha)
$sql = "UPDATE cadastro_empresa 
        SET nome_empresa=?, responsavel=?, telefone=? 
        WHERE id_empresa=?";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    http_response_code(500);
    exit("Erro no prepare: " . $conn->error);
}

$stmt->bind_param("sssi", $nome_empresa, $responsavel, $telefone, $id_empresa);

// EXECUTAR
if ($stmt->execute()) {
    http_response_code(200);
    echo "ok";
} else {
    http_response_code(500);
    echo "erro ao atualizar";
}

// Fechar statement
$stmt->close();

// ✅ $conn não é fechado, vem do conexao.php
?>
