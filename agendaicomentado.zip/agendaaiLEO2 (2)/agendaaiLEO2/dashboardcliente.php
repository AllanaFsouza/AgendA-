<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

$id = $_SESSION['id'] ?? 0; // busca o id da sessão inicializada

// BUSCAR COR DO TEMA DO USUÁRIO (inativado)
$sql = "SELECT cor_tema FROM cadastro_usuario WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$usuario = $result->fetch_assoc();

$cor = $usuario['cor_tema'] ?? '#6C63FF';

// Fechar statement (opcional)
$stmt->close();

// BUSCAR DADOS DA LOJA
$sql_loja = "SELECT nome_loja, localizacao, horario_abertura, horario_fechamento 
             FROM informacoes_loja 
             LIMIT 1";

$result_loja = $conn->query($sql_loja);
$loja = $result_loja->fetch_assoc();

$nome_loja = $loja['nome_loja'] ?? 'Empresa';
$localizacao = $loja['localizacao'] ?? 'Não definido';
$horario = isset($loja['horario_abertura'])
    ? substr($loja['horario_abertura'], 0, 5) . " - " . substr($loja['horario_fechamento'], 0, 5)
    : 'Não definido';
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empresa | Inicio</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --cor-tema: #6C63FF;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background: #f9fafb;
            min-height: 100vh;
        }

        header {
            background: var(--cor-tema);
            color: white;
            padding: 15px 40px;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
        }

        .logo-header {
            font-size: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        nav {
            display: flex;
            gap: 10px;
        }

        .nav-button {
            background: #fff;
            color: var(--cor-tema);
            border: none;
            border-radius: 12px;
            padding: 8px 18px;
            cursor: pointer;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            font-size: 14px;
            transition: .3s;
        }

        .nav-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, .15);
        }

        .nav-button.active {
            background: var(--cor-tema);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .header-user {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
        }

        .perfil-icon {
            background: white;
            color: var(--cor-tema);
            border: none;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 16px;
            transition: .3s;
        }

        .perfil-icon:hover {
            transform: scale(1.08);
        }

        .logout-header {
            font-size: 12px;
            text-decoration: none;
            color: white;
            opacity: .9;
            font-weight: 600;
            cursor: pointer;
        }

        .hero {
            background: var(--cor-tema);
            color: white;
            padding: 60px 40px 100px 40px;
        }

        .hero-container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .hero h1 {
            font-size: 36px;
            margin: 10px 0;
            font-weight: 800;
        }

        .hero p {
            opacity: .9;
            margin-bottom: 15px;
        }

        .cards-section {
            padding: 0 40px;
            margin-top: -60px;
        }

        .cards-container {
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .card {
            background: white;
            padding: 30px 20px;
            text-align: center;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .06);
            transition: .3s;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card i {
            font-size: 24px;
            margin-bottom: 10px;
            color: var(--cor-tema);
        }

        .card h3 {
            font-size: 22px;
            margin-bottom: 5px;
            color: #333;
        }

        .card p {
            font-size: 14px;
            color: #777;
        }

        .card-mascote .mascote-img {
            width: 70px;
            margin-bottom: 10px;
        }

        .xp-container {
            width: 100%;
            margin-top: 15px;
        }

        .xp-info {
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #333;
        }

        .progress-bar {
            width: 100%;
            height: 10px;
            background: #eee;
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-fill {
            width: 45%;
            height: 100%;
            background: linear-gradient(90deg, var(--cor-tema), #a29bfe);
        }

        .ver-beneficios {
            display: block;
            margin-top: 15px;
            font-size: 12px;
            color: var(--cor-tema);
            text-decoration: none;
            font-weight: 700;
            cursor: pointer;
        }

        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.45);
            backdrop-filter: blur(4px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: white;
            width: 420px;
            border-radius: 20px;
            padding: 35px;
            position: relative;
            border: 2px solid var(--cor-tema);
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.25);
            animation: modalEntrada .35s ease;
        }

        @keyframes modalEntrada {
            from {
                opacity: 0;
                transform: translateY(20px) scale(.95);
            }

            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .close-btn {
            position: absolute;
            top: 15px;
            right: 18px;
            font-size: 20px;
            cursor: pointer;
            color: #999;
        }

        .close-btn:hover {
            color: #ff4d4d;
        }

        .slider-container {
            width: 100%;
            overflow: hidden;
            position: relative;
        }

        .modal-viewport {
            display: flex;
            transition: transform .5s ease-in-out;
            width: 100%;
        }

        .nivel-slide {
            min-width: 100%;
            padding: 10px 20px;
        }

        .slider-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: var(--cor-tema);
            color: white;
            width: 38px;
            height: 38px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            cursor: pointer;
            box-shadow: 0 6px 14px rgba(0, 0, 0, 0.25);
        }

        .arrow-left {
            left: -18px;
        }

        .arrow-right {
            right: -18px;
        }

        .btn-ok {
            margin-top: 20px;
            background: var(--cor-tema);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            width: 100%;
        }

        .perfil-form {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 15px;
        }

        .perfil-form input {
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        .cor-area {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .cor-preview {
            width: 120px;
            height: 30px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        .paleta-cores {
            display: none;
            margin-top: 10px;
            background: #f9f9f9;
            padding: 10px;
            border-radius: 10px;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
        }

        .paleta-cores div {
            height: 25px;
            border-radius: 6px;
            cursor: pointer;
        }

        .btn-primario {
            background: var(--cor-tema);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            margin-top: 10px;
        }

        .btn-secundario {
            background: #eee;
            border: none;
            padding: 10px;
            border-radius: 12px;
            cursor: pointer;
        }

        .modal-logout {
            text-align: center;
        }

        .logout-botoes {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        .btn-confirmar {
            flex: 1;
            background: #e74c3c;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 700;
        }

        .btn-cancelar {
            flex: 1;
            background: #eee;
            border: none;
            padding: 12px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
        }

        /* MODAL BENEFÍCIOS - ESTILO MELHORADO */

        .modal-content {
            background: white;
            width: 450px;
            border-radius: 25px;
            padding: 40px 30px;
            position: relative;
            border: 2px solid var(--cor-tema);
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.25);
            animation: modalEntrada .4s ease;
        }

        @keyframes modalEntrada {
            from {
                opacity: 0;
                transform: translateY(30px) scale(.9);
            }

            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .slider-container {
            width: 100%;
            overflow: hidden;
            position: relative;
            margin-top: 10px;
        }

        .modal-viewport {
            display: flex;
            transition: transform .6s cubic-bezier(.77, 0, .18, 1);
            width: 100%;
        }

        .nivel-slide {
            min-width: 100%;
            padding: 10px 25px;
            text-align: left;
        }

        .nivel-slide h2 {
            font-size: 22px;
            margin-bottom: 10px;
        }

        .nivel-slide ul {
            margin-top: 10px;
            padding-left: 0;
        }

        .nivel-slide li {
            list-style: none;
            padding: 6px 0;
            font-size: 14px;
            color: #444;
        }

        /* SETAS ACIMA DO CONTEÚDO */
        .slider-arrow {
            position: absolute;
            top: -20px;
            transform: none;
            background: var(--cor-tema);
            color: white;
            width: 38px;
            height: 38px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
            transition: .3s;
        }

        .slider-arrow:hover {
            transform: scale(1.1);
        }

        .arrow-left {
            left: 10px;
        }

        .arrow-right {
            right: 10px;
        }

        .btn-ok {
            margin-top: 25px;
            background: var(--cor-tema);
            color: white;
            border: none;
            padding: 14px;
            border-radius: 14px;
            font-weight: 700;
            cursor: pointer;
            width: 100%;
            transition: .3s;
        }

        .btn-ok:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        /* SETAS CENTRALIZADAS NAS LATERAIS */
        .slider-arrow {
            position: absolute;
            top: 50%;
            /* Centraliza verticalmente */
            transform: translateY(-50%);
            /* Ajuste fino para o centro exato */
            background: var(--cor-tema);
            color: white;
            width: 38px;
            height: 38px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
            transition: .3s;
            z-index: 10;
            /* Garante que fiquem acima do texto */
        }

        .slider-arrow:hover {
            transform: translateY(-50%) scale(1.1);
            /* Mantém o centro no hover */
        }

        /* Ajuste das distâncias laterais para não ficarem coladas na borda */
        .arrow-left {
            left: -19px;
        }

        .arrow-right {
            right: -19px;
        }

        .cards-container {
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1.2fr 1.2fr 1.2fr 1fr;
            /* 3 maiores + mascote menor */
            gap: 20px;
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 100%;
            margin: 0;
        }

        .hero-container {
            max-width: 100%;
            margin: 0;
        }

        .cards-container {
            max-width: 100%;
            margin: 0;
            display: grid;
            grid-template-columns: 1.2fr 1.2fr 1.2fr 1fr;
            gap: 20px;
        }

        .cards-section {
            padding: 0 40px;
            margin-top: -60px;
        }

        /* opcional: deixa tudo mais "colado" à esquerda */
        header {
            padding: 15px 20px;
        }

        .hero {
            padding: 60px 20px 100px 20px;
        }

        .card-info,
        .cards-container .card:nth-child(2),
        .cards-container .card:nth-child(3) {
            padding: 15px 20px;
            /* diminui altura */
            height: 120px;
            /* altura fixa menor */
            justify-content: center;
        }

        .card-info h3,
        .cards-container .card:nth-child(2) h3,
        .cards-container .card:nth-child(3) h3 {
            font-size: 18px;
        }

        .card-info p,
        .cards-container .card:nth-child(2) p,
        .cards-container .card:nth-child(3) p {
            font-size: 12px;
        }

        @keyframes modalSaida {
            from {
                opacity: 1;
                transform: translateY(0) scale(1);
            }

            to {
                opacity: 0;
                transform: translateY(20px) scale(.9);
            }
        }

        .modal-saindo {
            animation: modalSaida .3s ease forwards;
        }

        @keyframes subirSuave {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .perfil-dado {
            padding: 10px;
            border-radius: 8px;
            background: #f1f5f9;
            border: 1px solid #ccc;
            font-weight: 500;
        }
    </style>

</head>

<body>
    <style>
        :root {
            --cor-tema:
                <?php echo $cor; ?>
            ;
        }

        /* Nova Seção de Galeria/Serviços */
        .gallery-section {
            padding: 40px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .gallery-title {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
            font-weight: 800;
        }

        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
        }

        .image-card {
            position: relative;
            height: 200px;
            border-radius: 20px;
            overflow: hidden;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        .image-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform .5s ease;
        }

        .image-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            padding: 20px;
            background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            opacity: 0.9;
            transition: .3s;
        }

        .image-card:hover img {
            transform: scale(1.1);
        }

        .image-card:hover .image-overlay {
            opacity: 1;
            background: linear-gradient(transparent, var(--cor-tema));
        }

        .image-overlay h4 {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .image-overlay p {
            font-size: 12px;
            opacity: 0.8;
        }

        /* MOBILE (até 768px) */
        @media (max-width: 768px) {

            .cards-section {
                margin-top: 20px;
                /* tira o negativo */
                padding: 0 20px;
            }

            .cards-container {
                grid-template-columns: 1fr;
                /* 1 card por linha */
                gap: 15px;
            }

            .card {
                height: auto;
                /* remove altura fixa */
                padding: 20px;
            }

            .hero {
                padding: 40px 20px 60px 20px;
                /* diminui espaço */
            }
        }

        /* MOBILE HEADER AJUSTADO */
        @media (max-width: 768px) {

            .header-content {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 8px;
            }

            .logo-header {
                font-size: 16px;
                gap: 5px;
            }

            nav {
                display: flex;
                gap: 6px;
                flex: 1;
                justify-content: center;
            }

            .nav-button {
                padding: 6px 10px;
                font-size: 12px;
                border-radius: 10px;
            }

            .header-user {
                flex-direction: row;
                /* <<< AQUI MUDA TUDO */
                gap: 6px;
            }

            .perfil-icon {
                width: 32px;
                height: 32px;
                font-size: 14px;
            }

            .logout-header {
                font-size: 11px;
            }
        }
    </style>

    <header>
        <div class="header-content">
            <div class="logo-header"><i class="fa-solid fa-scissors"></i>AgendaAí</div>

            <nav>
                <a href="dashboardcliente.php" class="nav-button active">Início</a>
                <a href="agendar.php" class="nav-button active">Agendar</a>
                <a href="meus.php" class="nav-button active">Meus</a>
            </nav>

            <div class="header-user">
                <button class="perfil-icon" onclick="abrirPerfilModal()"><i class="fa-solid fa-user"></i></button>
                <a class="logout-header" onclick="abrirModalLogout()">Sair</a>
            </div>

        </div>
    </header>

    <section class="hero">
        <div class="hero-container">
            <p>Olá, <?php echo $_SESSION['nome'] ?? 'usuário'; ?> 👋</p>

            <h1>Bem-vindo ao <?php echo $nome_loja; ?></h1>
            <p>Agende seu horário com facilidade e ganhe recompensas!</p>
            <a href="agendar.php" class="nav-button"><i class="fa-solid fa-calendar-check"></i> Agendar Agora</a>
        </div>
    </section>

    <section class="cards-section">
        <div class="cards-container">

            <div class="card card-info">
                <i class="fa-regular fa-star"></i>
                <h3>5.0</h3>
                <p>Sua Avaliação Média</p>
            </div>

            <div class="card">
                <i class="fa-regular fa-clock"></i>
                <h3><?php echo $horario; ?></h3>

                <p>Horário de Atendimento</p>
            </div>

            <div class="card">
                <i class="fa-solid fa-location-dot"></i>
                <h3><?php echo $localizacao; ?></h3>

                <p>Unidade Principal</p>
            </div>

            <div class="card card-mascote">
                <img src="https://cdn-icons-png.flaticon.com/512/3069/3069172.png" class="mascote-img">
                <h3>Preguicinha</h3>
                <div class="xp-container">
                    <div class="xp-info"><span>Nível 1</span><span>000/300 XP</span></div>
                    <div class="progress-bar">
                        <div class="progress-fill"></div>
                    </div>
                </div>
                <a class="ver-beneficios" onclick="abrirModal()">ver benefícios</a>
            </div>

        </div>
    </section>

    <section class="gallery-section">
        <h2 class="gallery-title">Nossos Serviços Populares</h2>
        <div class="gallery-grid">

            <div class="image-card">
                <img src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?q=80&w=500" alt="Corte Moderno">
                <div class="image-overlay">
                    <h4>Corte Moderno</h4>
                    <p>Estilos atuais e tendências</p>
                </div>
            </div>

            <div class="image-card">
                <img src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?q=80&w=500" alt="Barba Terapia">
                <div class="image-overlay">
                    <h4>Barba Terapia</h4>
                    <p>Cuidado completo para seu rosto</p>
                </div>
            </div>

            <div class="image-card">
                <img src="penteado.png" alt="Penteados">
                <div class="image-overlay">
                    <h4>Penteados</h4>
                    <p>Para ocasiões especiais</p>
                </div>
            </div>

            <div class="image-card">
                <img src="produtos.png" alt="Produtos">
                <div class="image-overlay">
                    <h4>Produtos Premium</h4>
                    <p>Linha exclusiva para cuidados</p>
                </div>
            </div>
            <div class="image-card">
                <img src="https://images.unsplash.com/photo-1560066984-138dadb4c035?q=80&w=500" alt="Hidratação">
                <div class="image-overlay">
                    <h4>Hidratação Profunda</h4>
                    <p>Nutrição para fios ressecados</p>
                </div>
            </div>

            <div class="image-card">
                <img src="https://images.unsplash.com/photo-1512496015851-a90fb38ba796?q=80&w=500" alt="Sobrancelha">
                <div class="image-overlay">
                    <h4>Design de Sobrancelha</h4>
                    <p>Limpeza e alinhamento do olhar</p>
                </div>
            </div>

            <div class="image-card">
                <img src="https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?q=80&w=500" alt="Selagem">
                <div class="image-overlay">
                    <h4>Selagem Térmica</h4>
                    <p>Redução de volume e frizz</p>
                </div>
            </div>

            <div class="image-card">
                <img src="limpeza.png" alt="Limpeza de Pele">
                <div class="image-overlay">
                    <h4>Limpeza de Pele</h4>
                    <p>Remoção de cravos e impurezas</p>
                </div>
            </div>

        </div>
    </section>

    <!-- MODAL BENEFICIOS -->
    <div class="modal-overlay" id="modalBeneficios">
        <div class="modal-content">

            <span class="close-btn" onclick="fecharModal()">&times;</span>

            <div class="slider-container">
                <div class="modal-viewport" id="modal-viewport"></div>
            </div>

            <div class="slider-arrow arrow-left" onclick="mudarNivel(-1)"><i class="fa-solid fa-chevron-left"></i></div>
            <div class="slider-arrow arrow-right" onclick="mudarNivel(1)"><i class="fa-solid fa-chevron-right"></i>
            </div>

            <button class="btn-ok" onclick="fecharModal()">OK</button>

        </div>
    </div>

    <!-- MODAL PERFIL -->
    <div class="modal-overlay" id="modalPerfil">
        <div class="modal-content">

            <span class="close-btn" onclick="fecharPerfilModal()">&times;</span>

            <h2><i class="fa-solid fa-circle-user"></i> Perfil</h2>

            <form class="perfil-form">
                <label>Nome</label>
                <div class="perfil-dado">
                    <?php echo $_SESSION['nome'] ?? 'Não definido'; ?>
                </div>

                <label>Email</label>
                <div class="perfil-dado">
                    <?php echo $_SESSION['email'] ?? 'Não definido'; ?>
                </div>


                <button type="button" class="btn-primario" onclick="salvarPerfil()">Salvar alterações</button>


            </form>

        </div>
    </div>

    <!-- MODAL LOGOUT -->
    <div class="modal-overlay" id="modalLogout">
        <div class="modal-content modal-logout">

            <h2><i class="fa-solid fa-right-from-bracket"></i> Sair</h2>
            <p style="margin-top:10px;color:#666;">Tem certeza que deseja encerrar sua sessão?</p>

            <div class="logout-botoes">
                <button class="btn-cancelar" onclick="fecharModalLogout()">Cancelar</button>
                <button class="btn-confirmar" onclick="confirmarLogout()">Sim, sair</button>
            </div>

        </div>
    </div>

    <script>

        // exibição dos benefícios (a ser modificada de acordo com o gosto e aceitação da cliente)

        const dadosNiveis = [
            { titulo: "🌟 Nível 1", itens: ["5% de desconto", "Prioridade na fila", "Acesso antecipado", "Selo exclusivo", "Dica mensal"] },
            { titulo: "🚀 Nível 5", itens: ["10% de desconto", "Agendamento VIP", "Suporte 24/7", "Brinde surpresa", "Prioridade máxima"] },
            { titulo: "💎 Nível 10", itens: ["20% de desconto", "Consultoria gratuita", "Convite VIP", "Produto personalizado", "Status Master"] },
            { titulo: "👑 Nível 15", itens: ["30% de desconto", "Agendamento prioritário", "Acesso a workshops", "Kit Boas-vindas", "Suporte exclusivo"] },
            { titulo: "🔥 Nível 20", itens: ["40% de desconto", "Consultoria VIP", "Eventos fechados", "Mimo personalizado", "Prioridade Platinum"] },
            { titulo: "🌌 Nível Supremo", itens: ["50% de desconto", "Parceria estratégica", "Cursos vitalícios", "Atendimento exclusivo", "VIP absoluto"] }
        ];

        let nivelAtual = 0;

        // rolagem 
        function inicializarSlides() {
            const viewport = document.getElementById("modal-viewport");
            viewport.innerHTML = dadosNiveis.map(n => `
<div class="nivel-slide">
<h2><i class="fa-solid fa-gem" style="color:var(--cor-tema)"></i> ${n.titulo}</h2>
<p>Benefícios:</p>
<ul>${n.itens.map(i => `<li>✅ ${i}</li>`).join("")}</ul>
</div>`).join("");
        }

        function abrirModal() {
            inicializarSlides();
            nivelAtual = 0;
            document.getElementById("modalBeneficios").style.display = "flex";
        }

        function fecharModal() {
            fecharComAnimacao("modalBeneficios");
        }

        function mudarNivel(d) { // para a gamificação (futura)
            nivelAtual = Math.max(0, Math.min(nivelAtual + d, dadosNiveis.length - 1));
            document.getElementById("modal-viewport").style.transform = `translateX(-${nivelAtual * 100}%)`;
        }

        /* PERFIL */

        function abrirPerfilModal() {
            document.getElementById("modalPerfil").style.display = "flex";
        }

        function fecharPerfilModal() {
            fecharComAnimacao("modalPerfil");
        }

        function salvarPerfil() {
            fecharPerfilModal();
        }

        /* CORES */ // inativo 

        function togglePaleta() {
            let p = document.getElementById("paletaCores");
            p.style.display = (p.style.display === "grid") ? "none" : "grid";
        }

        function selecionarCor(cor) {
            document.documentElement.style.setProperty('--cor-tema', cor);
            document.getElementById("previewCor").style.background = cor;

            fetch("salvar_cor.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: "cor=" + encodeURIComponent(cor),
                credentials: "include"
            });
        }


        function resetarCorTema() { // inativo
            selecionarCor("#6C63FF");
        }

        window.onload = () => {
            let cor = localStorage.getItem("corTemaSite");
            if (cor) {
                document.documentElement.style.setProperty('--cor-tema', cor);
                document.getElementById("previewCor").style.background = cor;
            }
        };

        /* LOGOUT */

        function abrirModalLogout() {
            document.getElementById("modalLogout").style.display = "flex";
        }

        function fecharModalLogout() {
            fecharComAnimacao("modalLogout");
        }

        function confirmarLogout() {
            window.location.href = "login_cliente.html";
        }

        function fecharComAnimacao(id) {
            const overlay = document.getElementById(id);
            const modal = overlay.querySelector(".modal-content");

            modal.classList.add("modal-saindo");

            setTimeout(() => {
                overlay.style.display = "none";
                modal.classList.remove("modal-saindo");
            }, 300);
        }
    </script>

    <!-- TRANSIÇÃO ENTRE PÁGINAS -->
    <script src="transicao.js"></script>
</body>

</html>