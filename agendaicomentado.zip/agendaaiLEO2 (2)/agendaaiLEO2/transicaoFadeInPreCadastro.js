/**
 * Transição Ultra Suave: Smooth Fade In (Sem barra inferior)
 * Versão corrigida para evitar scrolls indesejados e espaços em branco.
 */

(function() {
    // 1. CSS Corrigido
    const estilo = document.createElement('style');
    estilo.innerHTML = `
        /* Remove margens e impede scroll durante a transição */
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow-x: hidden;
        }

        /* Camada que cobre a tela no início */
        .fade-curtain {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: #6C63FF; 
            z-index: 99999;
            opacity: 1;
            transition: opacity 0.8s ease-in-out;
            pointer-events: none;
        }

        /* O conteúdo começa invisível e levemente deslocado */
        body {
            opacity: 0;
            transform: translateY(15px);
            transition: opacity 0.8s ease-out, transform 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        }

        /* Estado final da revelação */
        body.pagina-revelada {
            opacity: 1;
            transform: translateY(0);
        }

        .fade-curtain.escondida {
            opacity: 0;
        }
    `;
    document.head.appendChild(estilo);

    // 2. Criar a cortina
    const curtain = document.createElement('div');
    curtain.classList.add('fade-curtain');
    document.body.appendChild(curtain);

    // 3. Lógica de Entrada (Fade In)
    window.addEventListener('load', () => {
        requestAnimationFrame(() => {
            document.body.classList.add('pagina-revelada');
            curtain.classList.add('escondida');
            
            // Remove a cortina do DOM após a animação para não atrapalhar o layout
            setTimeout(() => {
                if(curtain.parentNode) curtain.parentNode.removeChild(curtain);
            }, 900);
        });
    });

    // 4. Lógica de Saída (Fade Out)
    document.addEventListener('click', (e) => {
        const link = e.target.closest('a');

        if (link && link.href && !link.target && !link.href.includes('#')) {
            const urlLink = new URL(link.href, window.location.origin);
            if (urlLink.origin !== window.location.origin) return;

            // Se for um link de download ou JS, não aplica
            if (link.getAttribute('download') !== null) return;

            e.preventDefault();

            // Recria a cortina apenas se ela foi removida
            if (!document.querySelector('.fade-curtain')) {
                const newCurtain = document.createElement('div');
                newCurtain.classList.add('fade-curtain');
                newCurtain.style.opacity = '0';
                document.body.appendChild(newCurtain);
                
                requestAnimationFrame(() => {
                    newCurtain.style.opacity = '1';
                    document.body.style.opacity = '0';
                    document.body.style.transform = 'translateY(-15px)';
                });
            }

            setTimeout(() => {
                window.location.href = link.href;
            }, 700);
        }
    });
})();