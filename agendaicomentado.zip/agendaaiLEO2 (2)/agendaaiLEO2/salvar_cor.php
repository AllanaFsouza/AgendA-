<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

if(!isset($_SESSION['id'])){
    exit("Não logado");
}

$cor = $_POST['cor'] ?? '';
$id = $_SESSION['id'];

if($cor && $id){
    $sql = "UPDATE cadastro_usuario SET cor_tema = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $cor, $id);
    $stmt->execute();
    $stmt->close(); // Fechar statement
    echo "ok";
} else {
    echo "Dados inválidos";
}

// ✅ $conn não é fechado, vem do conexao.php
?>
