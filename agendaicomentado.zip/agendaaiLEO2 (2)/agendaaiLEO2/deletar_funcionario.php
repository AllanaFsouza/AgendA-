<!-- trabalha com equipes.php -->

<?php
require_once "conexao.php"; // <-- usa a conexão centralizada

$id = $_POST['id'] ?? 0;

if($id){
    $sql = "DELETE FROM funcionarios_empresa WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if($stmt->execute()){
        echo "ok";
    } else {
        echo "erro";
    }

    // Fechar statement (opcional)
    $stmt->close();
}

?>
