<?php
// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$telefone = $_POST['telefone'] ?? '';
$senha = isset($_POST['senha']) ? password_hash($_POST['senha'], PASSWORD_DEFAULT) : '';

if (!$nome || !$email || !$telefone || !$senha) {
    echo "Todos os campos são obrigatórios.";
    exit;
}

$sql = "INSERT INTO cadastro_usuario (nome, email, telefone, senha) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $nome, $email, $telefone, $senha);

if($stmt->execute()){
    echo "Cadastro realizado com sucesso!";
}else{
    echo "Erro ao cadastrar";
}

// Fechar statement (opcional)
$stmt->close();

// ✅ $conn não é fechado, vem do conexao.php
?>
