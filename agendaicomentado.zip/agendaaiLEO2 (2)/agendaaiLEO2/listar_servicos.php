<!-- trabalha com serviços da página do admin, busca os serviços criados pelo admin e lista -->

<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

$empresa_id = $_SESSION['empresa_id'] ?? 0;

$servicos = [];

if($empresa_id){
    $sql = "SELECT * FROM servicos WHERE empresa_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $empresa_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while($row = $result->fetch_assoc()){
        $servicos[] = $row;
    }

    // Fechar statement (opcional)
    $stmt->close();
}

echo json_encode($servicos);
?>
