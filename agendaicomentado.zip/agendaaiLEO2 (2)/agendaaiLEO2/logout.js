/* LOGOUT EXCLUSIVO DA SIDEBAR */

document.addEventListener("DOMContentLoaded", function(){
const logoutBtn = document.getElementById("sidebarLogout");
if(!logoutBtn) return; /* se o botão não existir na página, o script para */


/* MODAL DE CONFIRMAÇÃO */

const modal = document.createElement("div");
modal.id = "logoutModalSidebar";
modal.innerHTML = `

<div class="logout-overlay">
<div class="logout-box">
<h2><i class="fa-solid fa-right-from-bracket"></i> Confirmar saída</h2>
<p>Tem certeza que deseja sair da sua conta?</p>
<div class="logout-buttons">
<button class="logout-cancel">Cancelar</button>
<button class="logout-confirm">Sair</button>
</div></div></div>
`;

document.body.appendChild(modal);

/* CSS DO MODAL DE CONFIRMAÇÃO */

const style = document.createElement("style");

style.innerHTML = `
#logoutModalSidebar{display:none;position:fixed;top:0;left:0;width:100%;height:100%;z-index:9999;align-items:center;justify-content:center;}
.logout-overlay{background:rgba(0,0,0,0.45);width:100%;height:100%;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);}
.logout-box{background:white;width:380px;padding:30px;border-radius:18px;text-align:center;box-shadow:0 20px 50px rgba(0,0,0,0.25);animation:logoutAnim .3s ease;}
@keyframes logoutAnim{from{opacity:0;transform:translateY(20px) scale(.95);}to{opacity:1;transform:translateY(0) scale(1);}}
.logout-box h2{font-size:20px;margin-bottom:10px;}
.logout-box p{font-size:14px;color:#666;margin-bottom:20px;}
.logout-buttons{display:flex;gap:10px;}
.logout-buttons button{flex:1;border:none;padding:10px;border-radius:10px;cursor:pointer;font-weight:600;font-size:14px;}
.logout-cancel{background:#eee;}
.logout-confirm{background:#e74c3c;color:white;}
`;

document.head.appendChild(style);


/* ABRIR MODAL */
logoutBtn.addEventListener("click", function(e){
e.preventDefault();
document.getElementById("logoutModalSidebar").style.display="flex";
});


/* CANCELAR */
modal.querySelector(".logout-cancel").addEventListener("click", function(){
modal.style.display="none";
});


/* CONFIRMAR LOGOUT */

modal.querySelector(".logout-confirm").addEventListener("click", function(){
document.body.style.transition="opacity .4s";
document.body.style.opacity="0";
setTimeout(function(){
window.location.href="login_empresa.html";
},400);
});


/* FECHAR CLICANDO FORA */

modal.querySelector(".logout-overlay").addEventListener("click", function(){
modal.style.display="none";});
modal.querySelector(".logout-box").addEventListener("click", function(e){
e.stopPropagation();});
});