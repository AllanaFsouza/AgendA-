<?php
session_start();

$nome_usuario = $_SESSION['empresa_nome'] ?? 'Admin';
$email_usuario = $_SESSION['empresa_email'] ?? 'admin@gmail.com';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sua Empresa | Serviços</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">

    <style>
        /* --- RESET E LAYOUT BASE --- */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { display: flex; height: 100vh; background: #e5e5e5; overflow: hidden; }

        /* --- SIDEBAR PADRONIZADA --- */
        .sidebar {
            width: 280px;
            background: #1b1f4b;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-shrink: 0;
        }

        .logo {
            padding: 25px 20px;
            font-weight: 800;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .menu {
            flex: 1;
            padding: 10px 0;
        }

        .menu-title {
            padding: 15px 20px 5px 20px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.5;
            font-weight: 600;
        }

        .menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            font-size: 14px;
            transition: 0.2s;
        }

        .menu a i {
            width: 20px;
            text-align: center;
            font-size: 16px;
        }

        .menu a:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .menu a.active {
            background: #4e63ff;
            font-weight: 600;
            border-radius: 0; /* Removido arredondamento para padrão full-width */
        }

        /* RODAPÉ DO USUÁRIO NA SIDEBAR */
        .sidebar-footer {
            padding: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .user-info-box {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .user-info-box i {
            background: white;
            color: #1b1f4b;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .user-details {
            display: flex;
            flex-direction: column;
        }

        .user-details strong {
            font-size: 13px;
            display: block;
        }

        .user-details span {
            font-size: 11px;
            opacity: 0.7;
        }

        .logout-btn {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            opacity: 0.8;
            transition: 0.2s;
        }

        .logout-btn:hover {
            opacity: 1;
        }

        /* --- CONTENT --- */
        .content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }

        .page-header {
            background: white;
            padding: 20px 30px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }

        .header-text h1 { font-size: 20px; color: #333; margin-bottom: 4px; }
        .header-text p { font-size: 12px; color: #777; }

        .notification-icon {
            width: 35px;
            height: 35px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #555;
            cursor: pointer;
        }

        /* --- CARDS DE RESUMO --- */
        .summary-cards { display: flex; gap: 20px; padding: 30px; }
        .card-small { background: white; padding: 20px; border-radius: 12px; border: 1px solid #ddd; flex: 1; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .card-small h3 { font-size: 28px; margin-bottom: 5px; }
        .card-small p { font-size: 13px; color: #777; font-weight: bold; }

        /* --- CONTAINER DE LISTA --- */
        .data-container { background: white; padding: 30px; border-radius: 20px; border: 1px solid #ddd; margin: 0 30px 30px 30px; }
        .section-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 30px; }

        .service-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px 25px;
            background: #fff;
            border: 1px solid #f0f0f0;
            border-radius: 12px;
            margin-bottom: 12px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
            transition: all 0.3s ease;
        }

        .service-item.disabled { opacity: 0.5; filter: grayscale(1); }
        .price { font-weight: bold; color: #333; min-width: 80px; text-align: right; }
        .duration { color: #888; min-width: 70px; font-size: 14px; text-align: right; }

        .btn-delete { color: #000; cursor: pointer; font-size: 18px; transition: 0.2s; }
        .btn-delete:hover { color: #dc3545; }

        /* Switch Style */
        .switch { position: relative; display: inline-block; width: 42px; height: 22px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ddd; transition: .4s; border-radius: 22px; }
        .slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #7b8aff; }
        input:checked + .slider:before { transform: translateX(20px); }

        /* --- MODAL --- */
        .modal { 
            display: none; 
            position: fixed; 
            top: 0; left: 0; width: 100%; height: 100%; 
            background: rgba(0,0,0,0.4); 
            z-index: 2000; 
            align-items: center; 
            justify-content: center; 
            backdrop-filter: blur(5px);
        }

        .modal-content { 
            background: white; 
            padding: 40px; 
            border-radius: 35px; 
            width: 450px; 
            text-align: center;
            box-shadow: 0 20px 50px rgba(0,0,0,0.15);
        }

        .modal-content h2 { color: #4e63ff; font-size: 24px; margin-bottom: 10px; display: flex; align-items: center; justify-content: center; gap: 10px; }
        .modal-input { width: 100%; padding: 15px; margin: 10px 0; border: 2px solid #eee; border-radius: 15px; font-size: 16px; outline: none; }
        .modal-input:focus { border-color: #4e63ff; }
        .modal-buttons { display: flex; justify-content: center; gap: 15px; margin-top: 20px; }
        .btn-cancel { background: #f0f0f0; color: #777; border: none; padding: 12px 30px; border-radius: 25px; font-weight: bold; cursor: pointer; }
        .btn-save { background: #4e63ff; color: white; border: none; padding: 12px 40px; border-radius: 25px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 15px rgba(78,99,255,0.3); }
    </style>
</head>

<body>

    <aside class="sidebar">
        <div>
       <div class="logo">
    <i class="fa-solid fa-scissors"></i> agendaAi
</div>
            <nav class="menu">
                <div class="menu-title">Editar site</div>
                <a href="dashboardadmin.php"><i class="fa-solid fa-chart-line"></i> Dashboard Inicial</a>
                <a href="previsualizacao_cliente.php"><i class="fa-regular fa-eye"></i> Pré-visualização</a>
                <a href="informacoes.php"><i class="fa-solid fa-circle-info"></i> Informações</a>
<a href="editardadosEmpresa.php"><i class="fa-solid fa-id-card"></i> Dados da Empresa</a>
                <div class="menu-title">Gerenciar</div>
                <a href="#" class="active"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</a>
                <a href="equipe.php"><i class="fa-solid fa-users"></i> Equipe</a>
                <a href="agendamentos.php"><i class="fa-regular fa-calendar-check"></i> Agendamentos</a>
                <a href="clientes.php"><i class="fa-solid fa-user-group"></i> Clientes</a>
                
            </nav>
        </div>

        <div class="sidebar-footer">
            <div class="user-info-box">
                <i class="fa-solid fa-user"></i>
                <div class="user-details">
    <strong><?php echo htmlspecialchars($nome_usuario); ?></strong>
    <span><?php echo htmlspecialchars($email_usuario); ?></span>
</div>
            </div>
            <a href="#" class="logout-btn" id="sidebarLogout">
                <i class="fa-solid fa-right-from-bracket"></i> Sair
            </a>
        </div>
    </aside>

    <main class="content">
        <header class="page-header">
            <div class="header-text">
                <h1>Serviços</h1>
                <p>Gerencie os serviços oferecidos pelo salão</p>
            </div>
            <div class="notification-icon">
                <i class="fa-solid fa-bell"></i>
            </div>
        </header>

        <div class="summary-cards">
            <div class="card-small"><h3 id="total-count" style="color: #4e63ff;">0</h3><p>Total</p></div>
            <div class="card-small"><h3 id="active-count" style="color: #28a745;">0</h3><p>Ativos</p></div>
            <div class="card-small"><h3 id="inactive-count" style="color: #dc3545;">0</h3><p>Inativos</p></div>
        </div>

        <div class="data-container">
            <div class="section-header">
                <div style="display:flex; align-items:center; gap:12px;">
                    <i class="fa-solid fa-scissors" style="font-size:24px; color:#4e63ff;"></i>
                    <div>
                        <h2 style="font-size:18px;">Listas de Serviços</h2>
                        <p style="font-size:12px; color:#888;">Gerencie preços, duração e disponibilidade</p>
                    </div>
                </div>
                <button onclick="abrirModal()" style="background:#4e63ff; color:white; border:none; padding:12px 25px; border-radius:10px; font-weight:bold; cursor:pointer;">
                    + Adicionar
                </button>
            </div>

            <div id="services-list">
                </div>
        </div>
    </main>

   <div id="addModal" class="modal">
    <div class="modal-content">
        <h2>📝 Novo Serviço</h2>
        <p style="color: #888; font-size: 14px;">
            Preencha os dados do novo serviço abaixo:
        </p>

        <!-- NOME -->
        <input type="text" id="nameInp" class="modal-input" placeholder="Nome do serviço...">

        <!-- PREÇO + TEMPO -->
        <div style="display:flex; gap:10px;">
            <input type="number" id="priceInp" class="modal-input" placeholder="Preço (R$)" min="0" step="0.01">
            <input type="text" id="timeInp" class="modal-input" placeholder="Tempo (ex: 30 min)">
        </div>

        <!-- 🔥 CATEGORIA -->
        <select id="categoryInp" class="modal-input">
            <option value="" disabled selected>Selecione a categoria</option>
            <option value="masculino">👨 Masculino</option>
            <option value="feminino">👩 Feminino</option>
        </select>

        <!-- BOTÕES -->
        <div class="modal-buttons">
            <button onclick="fecharModal()" class="btn-cancel">Cancelar</button>
            <button onclick="saveService()" class="btn-save">Salvar</button>
        </div>
    </div>
</div>


    <script>
const servicesContainer = document.getElementById('services-list');

function abrirModal() { 
    document.getElementById('addModal').style.display = 'flex'; 
}

function fecharModal() { 
    document.getElementById('addModal').style.display = 'none'; 
}

// 🔹 Carregar do banco
function loadFromStorage() {
    fetch('listar_servicos.php')
    .then(res => res.json())
    .then(data => {
        servicesContainer.innerHTML = '';

        data.forEach(s => {
            renderService(
                s.nome, 
                s.preco, 
                s.duracao, 
                s.ativo == 1, 
                s.id,
                s.categoria // 🔥 NOVO
            );
        });

        updateCounts();
    });
}

// 🔹 Renderizar serviço
function renderService(name, price, duration, active, id = null, categoria = '') {

    const checked = active ? 'checked' : '';
    const disabledClass = active ? '' : 'disabled';

    const html = `
        <div class="service-item ${disabledClass}">
            <div class="service-info" style="font-weight: 500;">
                ${name}<br>
                <small style="color:#888;">${categoria}</small>
            </div>

            <div style="display:flex; align-items:center; gap:30px;">
                <span class="price">R$ ${price}</span>
                <span class="duration">${duration}</span>

                <div style="display:flex; align-items:center; gap:15px; margin-left:10px;">
                    <label class="switch">
                        <input type="checkbox" ${checked} onchange="toggleStatus(this, ${id})">
                        <span class="slider"></span>
                    </label>

                    <i class="fa-regular fa-trash-can btn-delete" onclick="deleteService(this, ${id})"></i>
                </div>
            </div>
        </div>`;

    servicesContainer.insertAdjacentHTML('beforeend', html);
}

// 🔹 Deletar
function deleteService(el, id) {
    if(confirm("Excluir serviço?")) {

        fetch('deletar_servico.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `id=${id}`
        })
        .then(res => res.text())
        .then(res => {
            el.closest('.service-item').remove();
            updateCounts();
        });
    }
}

// 🔹 Ativar / desativar
function toggleStatus(input, id) {
    const item = input.closest('.service-item');
    const ativo = input.checked ? 1 : 0;

    item.classList.toggle('disabled', !input.checked);

    fetch('atualizar_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id=${id}&ativo=${ativo}`
    });

    updateCounts();
}

// 🔹 Contadores
function updateCounts() {
    const total = document.querySelectorAll('.service-item').length;
    const active = document.querySelectorAll('.service-item input:checked').length;

    document.getElementById('total-count').innerText = total;
    document.getElementById('active-count').innerText = active;
    document.getElementById('inactive-count').innerText = total - active;
}

// 🔥 SALVAR SERVIÇO (COM CATEGORIA + CORREÇÃO DO ID)
function saveService() {
    const name = document.getElementById('nameInp').value;
    const price = document.getElementById('priceInp').value;
    const time = document.getElementById('timeInp').value;
    const category = document.getElementById('categoryInp').value;

    if(!name || !price || !category) {
        return alert("Preencha todos os campos!");
    }

    fetch('salvar_servico.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `nome=${name}&preco=${price}&duracao=${time}&categoria=${category}`
    })
    .then(res => res.text())
    .then(res => {
        if(res === "ok"){
            fecharModal();

            // 🔥 RECARREGA DO BANCO (resolve problema do ID)
            loadFromStorage();
        }
    });
}

// 🔹 Inicializar
window.onload = loadFromStorage;
</script>


    <script src="logout.js"></script>
    <script src="transicao.js"></script>

</body>
</html>