<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

// 🔥 ID da empresa logada
$empresa_id = $_SESSION['empresa_id'] ?? 0;

$nome = $_POST['nome'] ?? '';
$funcao = $_POST['funcao'] ?? '';

if($empresa_id == 0){
    echo "erro_empresa";
    exit;
}

if(!$nome || !$funcao){
    echo "dados_invalidos";
    exit;
}

$stmt = $conn->prepare("INSERT INTO funcionarios_empresa (empresa_id, nome, funcao) VALUES (?, ?, ?)");
$stmt->bind_param("iss", $empresa_id, $nome, $funcao);

if($stmt->execute()){
    echo "ok";
}else{
    echo "erro";
}

$stmt->close(); // Fechar statement

// ✅ $conn não é fechado, vem do conexao.php
?>
