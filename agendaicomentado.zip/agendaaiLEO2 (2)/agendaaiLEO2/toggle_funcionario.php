<!-- trabalha com equipe, botão de ativa/desativa funcionários -->

<?php
session_start();

// INCLUIR CONEXÃO
require_once "conexao.php"; // conexão centralizada

if (!isset($_SESSION['empresa_id'])) {
    die("sem acesso");
}

$id = $_POST['id'] ?? 0;
$ativo = $_POST['ativo'] ?? 0;

if ($id) {
    $sql = "UPDATE funcionarios_empresa SET ativo = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("ii", $ativo, $id);
        if ($stmt->execute()) {
            echo "ok";
        } else {
            echo "erro";
        }
        $stmt->close(); // ✅ fechar statement
    } else {
        echo "erro no prepare";
    }
} else {
    echo "id_invalido";
}
?>
