<!-- Trabalha com agendamentos na página do admin, atualiza o status do agendamento para concluido --> 

<?php
require_once "conexao.php"; // <-- usa a conexão centralizada

if(isset($_POST['id'])){
    $id = intval($_POST['id']);

    $sql = "UPDATE agendamentos_cliente 
            SET status = 'concluido' 
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();

    echo "ok";

    // Fechar statement (opcional)
    $stmt->close();
}

// Não fechamos $conn, ele vem de conexao.php e pode ser usado em outros scripts
?>
