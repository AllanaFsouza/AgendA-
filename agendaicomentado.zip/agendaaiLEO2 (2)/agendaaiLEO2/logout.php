<?php
session_start();

// Remove todas as variáveis da sessão
$_SESSION = [];

// Destroi a sessão
session_destroy();

// (Opcional) Apaga o cookie da sessão também
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Redireciona para login
header("Location: login_empresa.html");
exit();
?>