<?php
session_start();
$nome = $_SESSION['empresa_nome'] ?? 'Usuário';
$email = $_SESSION['empresa_email'] ?? 'admin@email.com';

// INCLUIR CONEXÃO
require_once "conexao.php"; // <-- conexão centralizada

// PEGA ID DO USUÁRIO (cliente)
$id = $_SESSION['id'] ?? 0;

// BUSCAR COR E DADOS DO USUÁRIO
$cor = '#6C63FF';
if($id){
    $sql = "SELECT cor_tema, nome, email FROM cadastro_usuario WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();

    $cor = $usuario['cor_tema'] ?? '#6C63FF';
    $nome = $usuario['nome'] ?? $nome;
    $email = $usuario['email'] ?? $email;

    $stmt->close();
}

// BUSCAR DADOS DA EMPRESA / LOJA
$sql_loja = "SELECT nome_loja, localizacao, horario_abertura, horario_fechamento 
             FROM informacoes_loja 
             LIMIT 1";

$result_loja = $conn->query($sql_loja);
$loja = $result_loja->fetch_assoc();

$nome_loja = $loja['nome_loja'] ?? 'Empresa';
$localizacao = $loja['localizacao'] ?? 'Não definido';

$horario = isset($loja['horario_abertura']) 
    ? substr($loja['horario_abertura'],0,5) . " - " . substr($loja['horario_fechamento'],0,5)
    : 'Não definido';

// ✅ $conn não é fechado, vem do conexao.php
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Sua Empresa | Pré-visualização</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">

<style>
:root{
  --cor-tema: <?php echo $cor; ?>;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Inter',sans-serif;}
body{display:flex;height:100vh;background:#e5e5e5;}
.sidebar{width:280px;background:#1b1f4b;color:white;display:flex;flex-direction:column;justify-content:space-between;flex-shrink:0;}
.logo{padding:25px 20px;font-weight:800;font-size:18px;display:flex;align-items:center;gap:10px;border-bottom:1px solid rgba(255,255,255,0.08);}
.menu{flex:1;padding:10px 0;}
.menu-title{padding:15px 20px 5px 20px;font-size:11px;text-transform:uppercase;letter-spacing:0.5px;opacity:0.5;font-weight:600;}
.menu a{display:flex;align-items:center;gap:12px;padding:12px 20px;color:white;text-decoration:none;font-size:14px;transition:0.2s;}
.menu a i{width:20px;text-align:center;}
.menu a:hover{background:rgba(255,255,255,0.05);}
.menu a.active{background:#4e63ff;font-weight:600;}
.sidebar-user{padding:15px 20px;border-top:1px solid rgba(255,255,255,0.08);display:flex;justify-content:space-between;align-items:center;}
.user-left{display:flex;align-items:center;gap:10px;}
.user-left i{background:white;color:#1b1f4b;width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;}
.user-info strong{display:block;font-size:13px;}
.user-info span{font-size:11px;opacity:.7;}
.logout{color:white;text-decoration:none;display:flex;flex-direction:row;align-items:center;gap:5px;font-size:12px;opacity:.8;transition:.2s;}
.logout:hover{opacity:1;}
.content{flex:1;background:#f9fafb;overflow:auto;}
header{background:var(--cor-tema);color:white;padding:15px 40px;}

.header-content{display:flex;justify-content:space-between;align-items:center;}
.logo-header{font-size:20px;font-weight:700;}
nav{display:flex;gap:10px;}
.nav-button{background:#fff;color:var(--cor-tema);border:none;border-radius:12px;padding:8px 18px;cursor:pointer;font-weight:700;display:inline-flex;align-items:center;gap:8px;text-decoration:none;font-size:14px;transition:.3s;}
.nav-button:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.15);}
.nav-button.active{background:var(--cor-tema);color:#fff;}
.hero{background:var(--cor-tema);color:white;padding:60px 40px;gap:15px;transition:.4s;}
.hero h1{font-size:36px;margin:10px 0;line-height:1.2;font-weight:800;}
.hero p{opacity:.9;margin-bottom:10px;}
.hero .nav-button{align-self:flex-start;padding:12px 24px;margin-top:10px;}
.cards-section{padding:40px;margin-top:-60px;}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;align-items:start;}
.card{background:white;padding:20px;text-align:center;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,.06);transition:.3s;}
.card:hover{transform:translateY(-5px);}
.card i{font-size:20px;margin-bottom:8px;color:var(--cor-tema);}
.card p{font-size:13px;color:#777;}
.mascote-img{width:45px;margin-bottom:8px;}
.xp-container{margin-top:10px;}
.xp-info{display:flex;justify-content:space-between;font-size:11px;font-weight:700;margin-bottom:5px;}
.progress-bar{width:100%;height:8px;background:#eee;border-radius:10px;overflow:hidden;}
.progress-fill{width:45%;height:100%;background:linear-gradient(90deg,var(--cor-tema),#a29bfe);}
.card-mascote{min-height:250px;display:flex;flex-direction:column;justify-content:center;}
.card-mascote .mascote-img{width:65px;margin:0 auto 8px auto;}
.ver-beneficios{display:block;margin-top:20px;font-size:11px;color:var(--cor-tema);text-decoration:none;font-weight:600;cursor:pointer;}
.ver-beneficios:hover{text-decoration:underline;}
.modal-overlay{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.45);backdrop-filter:blur(4px);z-index:1000;align-items:center;justify-content:center;}
.modal-content{background:white;width:420px;border-radius:20px;padding:35px;position:relative;border:2px solid var(--cor-tema);box-shadow:0 25px 60px rgba(0,0,0,0.25);animation:modalEntrada .35s ease;}
@keyframes modalEntrada{from{opacity:0;transform:translateY(20px) scale(.95);}to{opacity:1;transform:translateY(0) scale(1);}}
.modal-content h2{font-size:22px;margin-bottom:10px;display:flex;align-items:center;gap:8px;}
.modal-content p{font-size:14px;color:#666;margin-bottom:15px;}
.modal-content ul{list-style:none;padding:0;margin:15px 0;}
.modal-content li{display:flex;align-items:center;gap:10px;background:#f7f8fc;padding:10px 12px;border-radius:10px;margin-bottom:8px;font-size:14px;}
.close-btn{position:absolute;top:15px;right:18px;font-size:20px;cursor:pointer;color:#999;transition:.2s;}
.close-btn:hover{color:#ff4d4d;}
.slider-container{width:100%;overflow:hidden;position:relative;}
.modal-viewport{display:flex;transition:transform .5s ease-in-out;width:100%;}
.nivel-slide{min-width:100%;box-sizing:border-box;padding:10px 20px 10px 30px;}
.slider-arrow{position:absolute;top:50%;transform:translateY(-50%);background:var(--cor-tema);color:white;width:38px;height:38px;display:flex;align-items:center;justify-content:center;border-radius:50%;cursor:pointer;box-shadow:0 6px 14px rgba(0,0,0,0.25);transition:.2s;}
.slider-arrow:hover{transform:translateY(-50%) scale(1.1);}
.arrow-left{left:-18px;}
.arrow-right{right:-18px;}
.btn-ok{margin-top:20px;background:var(--cor-tema);color:white;border:none;padding:12px;border-radius:12px;font-weight:700;cursor:pointer;width:100%;font-size:14px;transition:.25s;}
.btn-ok:hover{transform:translateY(-2px);box-shadow:0 8px 18px rgba(0,0,0,.2);}
.perfil-icon{background:white;color:var(--cor-tema);border:none;width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:16px;transition:.3s;margin-top:6px;}
.perfil-icon:hover{transform:scale(1.08);box-shadow:0 4px 10px rgba(0,0,0,.2);}
.modal-perfil{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:2000;align-items:center;justify-content:center;}
.modal-perfil-content{background:white;width:420px;border-radius:18px;padding:30px;position:relative;box-shadow:0 20px 50px rgba(0,0,0,0.25);}
.perfil-form{display:flex;flex-direction:column;gap:12px;margin-top:15px;}
.perfil-form label{font-size:13px;font-weight:600;}
.perfil-form input{padding:8px;border-radius:8px;border:1px solid #ccc;font-size:14px;}
.cor-area{display:flex;align-items:center;gap:10px;}
.cor-preview{width:120px;height:30px;border-radius:8px;border:1px solid #ccc;}
.escolher-cor{font-size:12px;color:var(--cor-tema);cursor:pointer;font-weight:600;}
.salvar-perfil{margin-top:10px;background:var(--cor-tema);color:white;border:none;padding:10px;border-radius:10px;cursor:pointer;font-weight:700;}
.reset-cor{margin-top:5px;background:#eee;border:none;padding:8px;border-radius:10px;cursor:pointer;}
.header-user{display:flex;flex-direction:column;align-items:center;gap:6px;}
.logout-header{font-size:12px;text-decoration:none;color:white;opacity:.9;display:flex;align-items:center;gap:5px;font-weight:600;}
.logout-header:hover{opacity:1;}
.modal-logout{text-align:center;}
.logout-botoes{display:flex;gap:10px;margin-top:20px;}
.btn-cancelar{flex:1;background:#eee;border:none;padding:10px;border-radius:10px;cursor:pointer;font-weight:600;}
.btn-confirmar{flex:1;background:#e74c3c;color:white;border:none;padding:10px;border-radius:10px;cursor:pointer;font-weight:700;}
.btn-confirmar:hover{background:#c0392b;}
.cor-seletor{display:flex;align-items:center;gap:10px;position:relative;}
.paleta-cores{display:none;margin-top:8px;background:white;padding:8px;border-radius:10px;box-shadow:0 10px 25px rgba(0,0,0,0.15);display:grid;grid-template-columns:repeat(3,20px);gap:6px;width:max-content;}
.paleta-cores div{width:18px;height:18px;border-radius:6px;cursor:pointer;border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,.2);transition:.2s;}
.paleta-cores div:hover{transform:scale(1.2);}

.sidebar-footer{padding:15px 20px;border-top:1px solid rgba(255,255,255,0.08);display:flex;justify-content:space-between;align-items:center;}
.user-info-box{display:flex;align-items:center;gap:10px;}
.user-info-box i{background:white;color:#1b1f4b;width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;}
.user-details strong{display:block;font-size:13px;color:white;}
.user-details span{font-size:11px;opacity:.7;color:white;}
.logout-btn{color:white;text-decoration:none;display:flex;flex-direction:row;align-items:center;gap:5px;font-size:12px;opacity:.8;transition:.2s;}
.logout-btn:hover { opacity: 1; }

/* Nova Seção de Serviços */
.services-section {
    padding: 0 40px 40px 40px;
    max-width: 1400px;
}

.services-title {
    font-size: 22px;
    color: #333;
    margin-bottom: 20px;
    font-weight: 800;
    display: flex;
    align-items: center;
    gap: 10px;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.service-card {
    position: relative;
    height: 180px;
    border-radius: 20px;
    overflow: hidden;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
}

.service-card img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform .5s ease;
}

.service-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(transparent, rgba(0,0,0,0.8));
    color: white;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: 20px;
    transition: .3s;
}

.service-card:hover img {
    transform: scale(1.1);
}

.service-card:hover .service-overlay {
    background: linear-gradient(transparent, var(--cor-tema));
}

.service-overlay h4 {
    font-size: 16px;
    font-weight: 700;
}

.service-overlay p {
    font-size: 12px;
    opacity: 0.8;
}

</style>
</head>

<body>

<div class="sidebar">
<div>
    <div class="logo">
    <i class="fa-solid fa-scissors"></i> agendaAi
</div>
<div class="menu">
<div class="menu-title">Editar site</div>
<a href="dashboardadmin.php"><i class="fa-solid fa-chart-line"></i> Dashboard Inicial</a>
<a href="#" class="active"><i class="fa-regular fa-eye"></i> Pré-visualização</a>
<a href="informacoes.php"><i class="fa-solid fa-circle-info"></i> Informações</a>
<a href="editardadosEmpresa.php"><i class="fa-solid fa-id-card"></i> Dados da Empresa</a>
<div class="menu-title">Gerenciar</div>
<a href="servicos.php"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</a>
<a href="equipe.php"><i class="fa-solid fa-users"></i> Equipe</a>
<a href="agendamentos.php"><i class="fa-solid fa-calendar"></i> Agendamento</a>
<a href="clientes.php"><i class="fa-solid fa-user"></i> Clientes</a>

</div></div>

<div class="sidebar-user">
<div class="user-left">
<i class="fa-solid fa-user"></i>
<div class="user-info">
<strong><?php echo $nome; ?></strong>
<span><?php echo $email; ?></span>
</div></div>

<a href="#" class="logout" id="sidebarLogout">
<i class="fa-solid fa-right-from-bracket"></i> Sair
</a>
</div></div>

<div class="content">

<header>
<div class="header-content"><div class="logo-header"><?php echo $nome_loja; ?></div>
<nav><a href="#" class="nav-button active">Início</a><a href="#" class="nav-button">Agendar</a><a href="#" class="nav-button">Meus</a></nav>
<div class="header-user">
<button class="perfil-icon" onclick="abrirPerfilModal()"><i class="fa-solid fa-user"></i></button>
<a href="#" class="logout-header" onclick="abrirModalLogout()"><i class="fa-solid fa-right-from-bracket"></i> Sair</a>
</div></div>
</header>

<section class="hero">
<p>Olá, <?php echo $nome; ?> 👋</p>
<h1>Bem-vindo ao <?php echo $nome_loja; ?></h1>
<p>Agende seu horário com facilidade e ganhe recompensas!</p>
<a href="#" class="nav-button"><i class="fa-solid fa-calendar-check"></i>Agendar Agora</a>
</section>

<section class="cards-section">
<div class="cards">
<div class="card">
<i class="fa-regular fa-star"></i><h3>5.0</h3><p>Sua Avaliação Média</p></div>
<div class="card"><i class="fa-regular fa-clock"></i><h3><?php echo $horario; ?></h3><p>Horário de Atendimento</p></div>
<div class="card"><i class="fa-solid fa-location-dot"></i><h3><?php echo $localizacao; ?></h3><p>Unidade Principal</p></div>

<div class="card card-mascote">
<img src="https://cdn-icons-png.flaticon.com/512/3069/3069172.png" class="mascote-img">
<h3>Preguicinha</h3>
<div class="xp-container">
<div class="xp-info"><span>Nível 1</span><span>135/300 XP</span></div>
<div class="progress-bar"><div class="progress-fill"></div></div>
<a class="ver-beneficios" onclick="abrirModal()">ver benefícios</a>
</div></div></div>

</section>

<section class="services-section">
    <h2 class="services-title"><i class="fa-solid fa-wand-magic-sparkles"></i> Nossos Serviços</h2>
    <div class="services-grid">
        
        <div class="service-card">
            <img src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?q=80&w=400">
            <div class="service-overlay">
                <h4>Corte Moderno</h4>
                <p>Estilos atuais e tendências</p>
            </div>
        </div>

        <div class="service-card">
            <img src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?q=80&w=500">
            <div class="service-overlay">
                <h4>Barba Terapia</h4>
                <p>Cuidado completo para seu rosto</p>
            </div>
        </div>

        <div class="service-card">
            <img src="penteado.png">
            <div class="service-overlay">
                <h4>Penteados</h4>
                <p>Para ocasiões especiais</p>
            </div>
        </div>

        <div class="service-card">
            <img src="produtos.png">
            <div class="service-overlay">
                <h4>Produtos Premium</h4>
                <p>Linha exclusiva para cuidados</p>
            </div>
        </div>

    </div>
</section>
</div>

<!-- MODAL BENEFÍCIOS -->
<div class="modal-overlay" id="modalBeneficios">
<div class="modal-content">
<span class="close-btn" onclick="fecharModal()">&times;</span>
<div class="slider-container"><div class="modal-viewport" id="modal-viewport"></div></div>
<div class="slider-arrow arrow-left" onclick="mudarNivel(-1)"><i class="fa-solid fa-chevron-left"></i></div>
<div class="slider-arrow arrow-right" onclick="mudarNivel(1)"><i class="fa-solid fa-chevron-right"></i></div>
<button class="btn-ok" onclick="fecharModal()">OK</button>
</div></div>

<!-- MODAL PERFIL -->
<div class="modal-perfil" id="modalPerfil">
<div class="modal-perfil-content">
<span class="close-btn" onclick="fecharPerfilModal()">&times;</span>

<h2>Perfil do Usuário</h2>
<form class="perfil-form">
<label>Nome</label><input type="text" placeholder="Nome cadastrado">
<label>Email</label><input type="email" placeholder="Email cadastrado">
<label>Cor do site</label><div class="cor-area">
<div class="cor-seletor"><div class="cor-preview" id="previewCor"></div>
<span class="escolher-cor" onclick="togglePaleta()">Escolher nova cor</span>

<div class="paleta-cores" id="paletaCores">
<div style="background:#000000" onclick="selecionarCor('#000000')"></div>
<div style="background:#ff6b6b" onclick="selecionarCor('#ff6b6b')"></div>
<div style="background:#27ae60" onclick="selecionarCor('#27ae60')"></div>
<div style="background:#3498db" onclick="selecionarCor('#3498db')"></div>
<div style="background:#f39c12" onclick="selecionarCor('#f39c12')"></div>
<div style="background:#9b59b6" onclick="selecionarCor('#9b59b6')"></div>
</div>

</div></div>

<button type="button" class="salvar-perfil" onclick="salvarCorTema()">Salvar alterações</button>
<button type="button" class="reset-cor" onclick="resetarCorTema()">Voltar cor original</button>
</form>

</div></div>

<!-- MODAL CONFIRMAÇÃO SAIR -->
<div class="modal-overlay" id="modalLogout">
<div class="modal-content modal-logout">
<span class="close-btn" onclick="fecharModalLogout()">&times;</span>
<h2><i class="fa-solid fa-right-from-bracket"></i> Confirmar saída</h2><p>Tem certeza que deseja sair da sua conta?</p>
<div class="logout-botoes">
<button class="btn-cancelar" onclick="fecharModalLogout()">Cancelar</button>
<button class="btn-confirmar" onclick="confirmarLogout()">Sair</button>
</div>

</div></div>

<script>

/* ALTERAR COR DO SISTEMA */
function salvarCorTema(){
let cor=document.getElementById("corTema").value;
document.documentElement.style.setProperty('--cor-tema',cor);
localStorage.setItem("corTemaSite",cor); }

/* RESETAR COR */
function resetarCorTema(){
let corOriginal="#6C63FF";
document.documentElement.style.setProperty('--cor-tema',corOriginal);
localStorage.setItem("corTemaSite",corOriginal);}

/* CARREGAR COR SALVA */
window.addEventListener("load",function(){
let corSalva=localStorage.getItem("corTemaSite");
if(corSalva){
document.documentElement.style.setProperty('--cor-tema',corSalva);}});

/* MODAL BENEFÍCIOS */
const dadosNiveis = [
{ titulo: "🌟 Nível 1", itens: ["5% de desconto","Prioridade na fila","Acesso antecipado","Selo exclusivo","Dica mensal"] },
{ titulo: "🚀 Nível 5", itens: ["10% de desconto","Agendamento VIP","Suporte 24/7","Brinde surpresa","Prioridade máxima"] },
{ titulo: "💎 Nível 10", itens: ["20% de desconto","Consultoria gratuita","Convite VIP","Produto personalizado","Status Master"] },
{ titulo: "👑 Nível 15", itens: ["30% de desconto","Agendamento prioritário","Acesso a workshops","Kit Boas-vindas","Suporte exclusivo"] },
{ titulo: "🔥 Nível 20", itens: ["40% de desconto","Consultoria VIP","Eventos fechados","Mimo personalizado","Prioridade Platinum"] },
{ titulo: "🌌 Nível Supremo", itens: ["50% de desconto","Parceria estratégica","Cursos vitalícios","Atendimento exclusivo","VIP absoluto"] }
];

let nivelAtual = 0;

function inicializarSlides(){
let viewport=document.getElementById("modal-viewport");
viewport.innerHTML=dadosNiveis.map(nivel=>`<div class="nivel-slide"><h2><i class="fa-solid fa-gem" style="color:var(--cor-tema)"></i> 
${nivel.titulo}</h2><p>Benefícios:</p><ul>
${nivel.itens.map(item=>`<li>✅ ${item}</li>`).join("")}</ul></div>`).join(""); }

function abrirModal(){
nivelAtual=0;
document.getElementById("modalBeneficios").style.display="flex";
document.getElementById("modal-viewport").style.transform="translateX(0%)"}

function fecharModal(){
document.getElementById("modalBeneficios").style.display="none";}

function mudarNivel(direcao){
nivelAtual+=direcao;
if(nivelAtual<0) nivelAtual=0;
if(nivelAtual>=dadosNiveis.length) nivelAtual=dadosNiveis.length-1;
document.getElementById("modal-viewport").style.transform=`translateX(-${nivelAtual*100}%)`;}

/* MODAL PERFIL */
function abrirPerfilModal(){
document.getElementById("modalPerfil").style.display="flex";}

function fecharPerfilModal(){
document.getElementById("modalPerfil").style.display="none";}

/* COR DO TEMA */
function salvarCorTema(){
let cor=document.getElementById("corTema").value;
document.documentElement.style.setProperty('--cor-tema',cor);
localStorage.setItem("corTemaSite",cor);
document.getElementById("previewCor").style.background=cor; }

function resetarCorTema(){
let corOriginal="#6C63FF";
document.documentElement.style.setProperty('--cor-tema',corOriginal);
localStorage.setItem("corTemaSite",corOriginal);
document.getElementById("previewCor").style.background=corOriginal; }

/* CARREGAR COR SALVA */
window.addEventListener("load",function(){
let corSalva=localStorage.getItem("corTemaSite");
if(corSalva){
document.documentElement.style.setProperty('--cor-tema',corSalva);
document.getElementById("previewCor").style.background=corSalva; }

inicializarSlides(); });

/* MODAL LOGOUT */
function abrirModalLogout(){
document.getElementById("modalLogout").style.display="flex";}

function fecharModalLogout(){
document.getElementById("modalLogout").style.display="none";}

function togglePaleta(){
let paleta=document.getElementById("paletaCores");
if(paleta.style.display==="grid"){paleta.style.display="none";
}else{paleta.style.display="grid"; }}

function selecionarCor(cor){
document.documentElement.style.setProperty('--cor-tema',cor);
localStorage.setItem("corTemaSite",cor);
document.getElementById("previewCor").style.background=cor;
document.getElementById("paletaCores").style.display="none"; }

function togglePaleta(){
let paleta=document.getElementById("paletaCores");
if(paleta.style.display==="flex"){paleta.style.display="none";
}else{paleta.style.display="flex";} }

function togglePaleta(){
let paleta = document.getElementById("paletaCores");
if(paleta.style.display === "grid"){paleta.style.display = "none";
}else{paleta.style.display = "grid";} }

</script>

<!-- LOG OUT PADRÃO PARA TODAS AS PÁGINAS -->
<script src="logout.js"></script>
<script src="transicao.js"></script>


</body>
</html>